import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'home',
      component: () => import('../views/Home')
    },
    {
      path: '/search',
      name: 'search',
      component: () => import('../views/Search')
    },
    {
      path: '/soft',
      name: 'soft',
      component: () => import('../views/Soft')
    },
    {
      path: '/softres',
      name: 'softres',
      component: () => import('../views/SoftRes')
    },
    {
      path: '/chapters',
      name: 'chapters',
      component: () => import('../views/Chapters')
    },
    {
      path: '/content',
      name: 'content',
      component: () => import('../views/Content')
    }
  ]
})
