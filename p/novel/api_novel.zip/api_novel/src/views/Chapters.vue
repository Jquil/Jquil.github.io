<template>
    <div>{{ json }}</div>
</template>

<script>
/**
 * url：/chapters?url=/book/71384/
 *  {
        "title":"第1章 序章：离别地球的最后一封信",
        "url":"/book/71384/236081.html"
    }
 */
import {getChapters} from '@/api/base'
const cheerio = require('cheerio')
export default {
    name: 'Chapters',
    data(){
        return{
            json:'',
            url:''
        }
    },
    methods:{
        get(url){
            getChapters(url)
            .then(res => {
                this.filter(res.data)
            })
        },
        filter(html){
            //console.log(html)
            let $ = cheerio.load(html)
            let children = $('#list')[0].children[1].children
            let arr = []
            for(let i = 0; i < children.length; i++){
                let temp = {}
                if(children[i].name != 'dd')
                    continue
                temp.title = children[i].children[0].children[0].data
                temp.url   = children[i].children[0].attribs.href
                arr.push(temp)
            }
            this.json = JSON.stringify(arr)
        }
    },
    mounted(){
            let url   = this.$route.query.url
            this.url  = url
            this.get(url)
    },
    watch: {
        '$route':{
            handler(to){
                if(this.url != to.query.url){
                    this.url = to.query.url
                    this.get(this.url)
                }
            }
        }
    }

}
</script>