<template>
    <div>
        {{ json }}
    </div>
</template>

<script>
/** 
 * url：/search?key=元
 * {
        "title":"帕弥什纪元",
        "url":"/book/71384/",
        "desc":"毒雾弥漫、生命垂危的最后一刻…凛终于看清了、他看清了绝对禁区中的那一片无底黑暗深渊——残缺的神像、碎裂的国徽、血染的白羽、崩坏的人脸、虚幻的灵魂……此时此刻似乎世间所有可见或不可见、有生命或无生命之物，都已在堙灭在这无尽暗渊之内彻底沦落为帕弥什病毒的初生温床……",
        "author":"一叶十秋",
        "type":"其他小说",
        "newestTime":"2022-02-07 08:04:42",
        "newestChapter":"2022-02-07 08:04:42",
        "pic":"https://www.sobiquge.com/files/article/image/71/71384/71384s.jpg"
    }
*/
import {search} from '@/api/base'
const cheerio = require('cheerio')
export default ({
    name: 'Search',
    data(){
        return{
            key:'',
            json:''
        }
    },
    methods:{
        _search(key){
            search(key).then(res => { this.filter(res.data) })
        },
        filter(html){
            let $ = cheerio.load(html)
            let title = $(".result-game-item-title-link")
            let arr = []
            for(let i = 0; i < title.length; i++){
                let temp = {}
                temp.title = $(title[i])[0].attribs.title
                temp.url   = $(title[i])[0].attribs.href
                temp.desc  = $('.result-game-item-desc')[i].children[0].data

                let info = $(".result-game-item-info")[i]
                let tag  = $(info).find('.result-game-item-info-tag')
                temp.author        = tag[0].children[3].children[0].data
                temp.type          = tag[1].children[3].children[0].data
                temp.newestTime    = tag[2].children[3].children[0].data
                temp.newestChapter = tag[2].children[3].children[0].data
                temp.pic           = $('.result-game-item-pic-link')[i].children[1].attribs.src
                arr.push(temp)
            }
            this.json = JSON.stringify(arr)
        }
    },
    mounted(){
        let key = this.$route.query.key
        this.key = key
        this._search(key)
    },
    watch: {
        '$route':{
            handler(to){
                if(this.key != to.query.key){
                    this.key = to.query.key
                    this.search(this.key)
                }
            }
        }
    }
})
</script>
