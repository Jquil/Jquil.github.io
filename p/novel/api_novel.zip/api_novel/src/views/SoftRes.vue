<template>
    <div>{{ json }}</div>
</template>

<script>
/**
 * url：/softres?url=/xuanhuan/
 * {
        "title":"混元剑主",
        "url":"/book/66846/",
        "pic":"https://www.sobiquge.com/files/article/image/66/66846/66846s.jpg",
        "author":"作者：欧阳晕",
        "desc":"九界独尊，八荒寂灭，天地一法混元！神魔枭首，圣灵跪伏，万古唯我神剑！"
   }
 */
import {getSoftRes} from '@/api/base'
const cheerio = require('cheerio')
export default {
    name: 'SoftRes',
    data(){
        return{
            json: "",
            url:''
        }
    },
    methods:{
        get(url){
            getSoftRes(url)
            .then(res => {
                this.filter(res.data)
            })
        },
        filter(html){
            let $  = cheerio.load(html)
            let arr1 = [],arr2 = []

            let item = $(".bookbox")
            for(let i = 0; i < item.length; i++){
                let temp = {}
                temp.title  = $(item)[i].children[3].children[0].children[0].children[0].children[0].data
                temp.url  = $(item)[i].children[1].childNodes[0].attribs.href
                temp.pic  = $(item)[i].children[1].childNodes[0].children[0].attribs.src
                temp.author = $(item)[i].children[3].children[1].children[0].data
                temp.desc = $(item)[i].children[3].children[7].children[1].data
                arr1.push(temp)
            }

            let temp = {}
            temp.hot = arr1
            this.json = temp
        }
    },
    mounted(){
        let url   = this.$route.query.url
        this.url  = url
        this.get(url)
    },
    watch:{
        '$route':{
            handler(to){
                if(this.url != to.query.url){
                    this.url = to.query.url
                    this.get(this.url)
                }
            }
        }
    }
}
</script>