import axios from 'axios'

const service = axios.create()

const api_pc = "https://biquge-pc.jqwong.cn"

const api_mobile = "https://biquge-mobile.jqwong.cn"

export function search(key){
    return service({
        method:'get',
        url:`${api_mobile}/search.php?q=${key}`
    })
}

export function getSoft(){
    return service({
        method:'get',
        url:`${api_mobile}/sort.html`
    })
}

export function getSoftRes(url){
    return service({
        method:'get',
        url:`${api_mobile}${url}`
    })
}

export function getChapters(url){
    return service({
        method:'get',
        url:`${api_pc}${url}`
    })
}

export function getContent(url){
    return service({
        method:'get',
        url:`${api_pc}${url}`
    })
}