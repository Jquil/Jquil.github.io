﻿using System;
using System.IO;
using System.Linq;

namespace ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var input = File.ReadAllText("D:\\《斗破苍穹》第一章.txt");
            var result = LZ77Coding.encode(input,System.Text.Encoding.UTF8);
            var code_map1 = HuffmanCoding.toMap(HuffmanCoding.encode(result.list_literal_code));
            var code_map2 = HuffmanCoding.toMap(HuffmanCoding.encode(result.list_distance_code));
            HuffmanCoding.serialize(code_map1, code_map2);
            Console.ReadKey();
        }
    }
}