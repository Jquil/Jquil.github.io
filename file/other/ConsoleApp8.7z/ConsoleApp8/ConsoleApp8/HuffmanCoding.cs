﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp
{
    public class HuffmanCoding
    {
        public static HuffmanNode encode(List<int> list) {
            var pairs = new Dictionary<int,int>();
            list.ForEach(it =>
            {
                if(pairs.ContainsKey(it)) pairs[it]++;
                else pairs.Add(it, 1);
            });
            pairs = pairs.OrderBy(it=>it.Key).OrderBy(it => it.Value).ToDictionary(it=>it.Key,it=>it.Value);
            var nodes = new List<HuffmanNode>();
            foreach(var it in pairs)
            {
                nodes.Add(new HuffmanNode() { 
                    left = null,
                    right = null,
                    data = it.Key,
                    weight= it.Value,
                });
            }
            while(nodes.Count != 1)
            {
                // 保证左节点小于右节点
                var node = new HuffmanNode()
                {
                    data = -1,
                    left = nodes[0].data <= nodes[1].data ? nodes[0] : nodes[1],
                    right = nodes[0].data > nodes[1].data ? nodes[0] : nodes[1],
                    weight = nodes[0].weight + nodes[1].weight
                };
                nodes.RemoveAt(0);
                nodes.RemoveAt(0);
                if (!nodes.Any() || node.weight >= nodes.Last().weight)
                {
                    nodes.Add(node);
                }
                else
                {
                    for(var i = 0; i < nodes.Count; i++)
                    {
                        var it = nodes[i];
                        if(it.weight > node.weight)
                        {
                            nodes.Insert(i, node);
                            break;
                        }
                    }
                }
            }
            return nodes.First();
        }
        public static void decode() { }
        public static Dictionary<int, string> toMap(HuffmanNode root) {
            var pairs = new Dictionary<int, string>();
            void collect(HuffmanNode node,string code) {
                if(node.left != null)
                {
                    collect(node.left, $"{code}0");
                }
                if(node.right != null)
                {
                    collect(node.right, $"{code}1");
                }
                if(node.left == null && node.right == null)
                {
                    pairs.Add(node.data, code);
                }
            }
            collect(root, string.Empty);
            return pairs;
        }
        public static List<bool> serialize(Dictionary<int,string> literal_map,Dictionary<int,string> distance_map) {
            /**
             * 码表序列化: 内部实现进一步压缩 
             * (1) 记录两个码表的码长, 对应两个int[]数组
             *    >> PK规定码长最长不超过15, 但由于对深度超过15的分枝不太好处理且解码时不太好还原, 我们将限制改成20
             * (2) 对这两个数组进行游程编码, 缩短长度
             *    >> PK使用17/18作为连续出现0时的标识符, 由于我们前面调整最大码长限制, 所以这两个数字也要调整
             *    >> 我们用22,23替代17/18, X+1作为其他数字连续出现标识符
             *    >> 因此编码后结果(序列)内任意值应该在0~23之间
             * (3) 对游程编码后这两个序列进行合并, 然后进行哈夫曼编码
             *    >> 编码后输出[bits1,bits2]
             *    >> 同样用记录码长的方式记录码表, 最后使用N位bit记录
             */
            var code_length_literal = new int[286];
            var code_length_distance = new int[30];
            foreach(var it in literal_map)
            {
                code_length_literal[it.Key] = it.Value.Length;
            }
            foreach(var it in distance_map)
            {
                code_length_distance[it.Key] = it.Value.Length;
            }
            var sq1 = RLECoding.encode(code_length_literal);
            var test = RLECoding.decode(sq1);
            for(var i = 0; i < code_length_literal.Length; i++)
            {
                if (code_length_literal[i] != test[i])
                {
                    Console.WriteLine($"{code_length_literal[i]},{test[i]}");
                }
            }
            Console.WriteLine("finish");
            return default;
        }
        public static void deserialize() { 
            
        }
        public class HuffmanNode
        {
            public int data;
            public int weight;
            public HuffmanNode left;
            public HuffmanNode right;
        }
    }
}
