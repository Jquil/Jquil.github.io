﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp
{
    public class LZ77Coding
    {
        private readonly static string ERROR_PARSE = "parse failed!";
        private readonly static int[][] MAP_LENGTH = new int[][] {
            // range + extend bits
            new int[]{ 3 },
            new int[]{ 4 },
            new int[]{ 5 },
            new int[]{ 6 },
            new int[]{ 7 },
            new int[]{ 8 },
            new int[]{ 9 },
            new int[]{ 10 },
            new int[]{ 11,12,1 },
            new int[]{ 13,14,1 },
            new int[]{ 15,16,1 },
            new int[]{ 17,18,1 },
            new int[]{ 19,22,2 },
            new int[]{ 23,26,2 },
            new int[]{ 27,30,2 },
            new int[]{ 31,34,2 },
            new int[]{ 35,42,3 },
            new int[]{ 43,50,3 },
            new int[]{ 51,58,3},
            new int[]{ 59,66,3 },
            new int[]{ 67,82,4 },
            new int[]{ 83,98,4 },
            new int[]{ 99,114,4 },
            new int[]{ 115,130,4 },
            new int[]{ 131,162,5 },
            new int[]{ 163,194,5 },
            new int[]{ 195,226,5 },
            new int[]{ 227,257,5 },
            new int[]{ 258 },
        };
        private readonly static int[][] MAP_DISTANCE = new int[][] {
            // range + extend bits
            new int[]{ 1 },
            new int[]{ 2 },
            new int[]{ 3 },
            new int[]{ 4 },
            new int[]{ 5,6,1 },
            new int[]{ 7,8,1 },
            new int[]{ 9,12,2 },
            new int[]{ 13,16,2 },
            new int[]{ 17,24,3 },
            new int[]{ 25,32,3 },
            new int[]{ 33,48,4 },
            new int[]{ 49,64,4 },
            new int[]{ 65,96,5 },
            new int[]{ 97,128,5 },
            new int[]{ 129,192,6 },
            new int[]{ 193,256,6 },
            new int[]{ 257,384,7 },
            new int[]{ 385,512,7 },
            new int[]{ 513,768,8 },
            new int[]{ 769,1024,8 },
            new int[]{ 1025,1536,9 },
            new int[]{ 1537,2048,9},
            new int[]{ 2049,3072,10 },
            new int[]{ 3073,4096,10 },
            new int[]{ 4097,6146,11 },
            new int[]{ 6145,9182,11 },
            new int[]{ 8193,12888,12 },
            new int[]{ 12289,16384,12 },
            new int[]{ 16385,24576,13 },
            new int[]{ 24577,32786,13 },
        };
        public static Result encode(string input,Encoding encoding) {
            /**
             ** LZ77编码:相同字符串使用(distance,length)表示
             *** 菲尔卡兹(Phil Katz,PK)限定相同字符串长度只有超过等于3才进行编码
             *** (一) 输入内容最终会转化为字节流的形式进行存储或传输, 1个字节在0~255之间, 因此输入内容也就是一连串0~255的数字
             *** 当出现相同字符串且长度大于等于3时, 使用大于255的数字来标识相同字符串长度;
             *** PK规定256代表'解码结束',257表示相同字符串长度=3,258表示相同字符串长度=4,...
             *** 因此这里用了一个数字来结合两者的意思: 小于256代表普通字符(literal),大于256代表相同字符串长度(length) 
             *--
             *** (二) distance表示距离前面相同字符串的位置, 通过distance+length就能解析出相同的字符串
             *** PK限定distance为32768, 也就是最多向前找32768个字符, 超过就不找了; 同时也限定相同字符串长度最大为256,
             *** 相同字符串长度256很小概率出现了,假如出现了再用(distance,length)方式进行编码
             *--
             *** (三) 为了进一步缩小distance,length数字的范围,PK设定了区间+扩展码: 往往出现相同内容会就近出现(这里是一个概率问题)
             *** 例如: 和朋友聊天. 早上聊家庭,聊的内容或许有60%可能相同; 下午聊游戏,这时出现家庭的内容可能就只有30%了;
             *** 而区间+扩展码的方式则可以用较少的bit来表示距离短的数字,用较多的bit来表示距离较远的数字
             *--
             *** (四) 区间+扩展码同样也用在了length上, 前面知道我们用一个数字就用来表示了是普通字符还是长度, 并且知道了相同字符串
             *** 长度被限定在了258, 因此这个数字的范围是在0~511,当我们对于length部分也进行区间+扩展码方式来表示同样也缩小这个数字的范围
             */
            var window = new StringBuilder(32768);
            var buffer = new StringBuilder(256);
            var list_literal_code = new List<int>();
            var list_literal_extend_code = new List<string>();
            var list_distance_code = new List<int>();
            var list_distance_extend_code = new List<string>();

            // 预加载
            buffer.Append(input.Length>buffer.Capacity?input.Substring(0,buffer.Capacity):input);
            var cursor = buffer.Length;

            while (buffer.Length != 0) {
                // 匹配相同字符串
                var index = 0;
                var ch = buffer[index++];
                var match_list = new List<(string child,int index)>();
                match_list.Add((ch.ToString(),window.ToString().LastIndexOf(ch.ToString())));
                while(match_list.Last().index != -1)
                {
                    if ((match_list.Last().index + match_list.Last().child.Length) >= buffer.Length)
                        break;
                    ch = buffer[index++];
                    var child = match_list.Last().child + ch.ToString();
                    match_list.Add((child, window.ToString().LastIndexOf(child)));
                }
                // 寻找最长匹配字符串
                for(var i = match_list.Count-1; i >= 0; i--)
                {
                    var it = match_list[i];
                    if(it.index == -1)
                    {
                        match_list.RemoveAt(i);
                    }
                    else
                    {
                        break;
                    }
                }
                if (!match_list.Any())
                {
                    // 如果没有匹配内容或则原样输出
                    foreach (var it in encoding.GetBytes(ch.ToString()))
                    {
                        list_literal_code.Add(it);
                    }
                }
                else if (match_list.Last().child.Length < 3) {
                    // 如果匹配长度小于3原样输出
                    foreach (var it in encoding.GetBytes(match_list.Last().child))
                    {
                        list_literal_code.Add(it);
                    }
                }
                else
                {
                    // 获取length-code&&length_extend_code
                    var match_info = match_list.Last();
                    var length = match_info.child.Length;
                    var length_code = -1;
                    var length_extend_code = string.Empty;
                    for (var i = 0; i < MAP_LENGTH.Length; i++)
                    {
                        var it = MAP_LENGTH[i];
                        if (it.Length == 1)
                        {
                            if (it[0] == length)
                            {
                                length_code = 257 + i;
                                break;
                            }
                        }
                        else if (it.Length == 3)
                        {
                            if (length >= it[0] && length <= it[1])
                            {
                                length_code = 257 + i;
                                var bit_num = it[2];
                                var extend_bit = 0;
                                for (var j = it[0]; j < it[1]; j++)
                                {
                                    if (j == length)
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        extend_bit++;
                                    }
                                }
                                length_extend_code = Convert.ToString(extend_bit, 2).PadLeft(bit_num, '0');
                                break;
                            }
                        }
                        else
                        {
                            throw new Exception("get length code failed!");
                        }
                    }
                    if (length_code == -1)
                    {
                        throw new Exception("get length code failed!");
                    }

                    // 获取distance-code&&distance_extend_code
                    var distance = window.Length - match_info.index;
                    var distance_code = -1;
                    var distance_extend_code = string.Empty;
                    for (var i = 0; i < MAP_DISTANCE.Length; i++)
                    {
                        var it = MAP_DISTANCE[i];
                        if (it.Length == 1)
                        {
                            if (it[0] == distance)
                            {
                                distance_code = i;
                                break;
                            }
                        }
                        else if (it.Length == 3)
                        {
                            if (distance >= it[0] && distance <= it[1])
                            {
                                distance_code = i;
                                var bit_num = it[2];
                                var extend_bit = 0;
                                for (var j = it[0]; j <= it[1]; j++)
                                {
                                    if (j == distance)
                                    {
                                        break;
                                    }
                                    extend_bit++;
                                }
                                distance_extend_code = Convert.ToString(extend_bit, 2).PadLeft(bit_num, '0');
                                break;
                            }
                        }
                        else
                        {
                            throw new Exception("get distance code failed!");
                        }
                    }
                    if (distance_code == -1)
                    {
                        throw new Exception("get distance code failed!");
                    }

                    list_literal_code.Add(length_code);
                    list_literal_extend_code.Add(length_extend_code);
                    list_distance_code.Add(distance_code);
                    list_distance_extend_code.Add(distance_extend_code);
                }

                // 继续装载
                var move_length = match_list.Any() ? match_list.Last().child.Length : 1;
                buffer.Remove(0,move_length);
                if(cursor < input.Length)
                {
                    var add_length = cursor + move_length > input.Length ? input.Length - cursor : move_length;
                    buffer.Append(input.Substring(cursor, add_length));
                    cursor += add_length;
                }
                if (window.Length + move_length > window.Capacity) { 
                    window.Remove(0,window.Length + move_length - window.Capacity);
                }
                window.Append(move_length == 1 ? ch.ToString() : match_list.Last().child);
                if(cursor > 3000)
                {

                }
            }
            list_literal_code.Add(256);
            return new Result(list_literal_code,list_literal_extend_code,list_distance_code,list_distance_extend_code);
        }
        public static string decode(Result result, Encoding encoding) {
            var buffer = new List<byte>();
            var builder = new StringBuilder();
            foreach(var literal_code in result.list_literal_code)
            {
                if(literal_code < 256)
                {
                    buffer.Add((byte)literal_code);
                }
                else if(literal_code > 256) {

                    var length = -1;
                    {
                        var length_code = literal_code - 257;
                        if (length_code >= MAP_LENGTH.Length || length_code < 0)
                        {
                            throw new Exception(ERROR_PARSE);
                        }
                        var it = MAP_LENGTH[length_code];
                        if(it.Length == 1)
                        {
                            length = it[0];
                        }
                        else if(it.Length == 3)
                        {
                            var bit_num = it[2];
                            var extend_bit = result.list_literal_extend_code.First();
                            if (string.IsNullOrEmpty(extend_bit) || extend_bit.Length != bit_num)
                            {
                                throw new Exception(ERROR_PARSE);
                            }
                            var num = 0;
                            for(var i = 0; i <= it[1]-it[0]; i++)
                            {
                                var num_str = Convert.ToString(i,2).PadLeft(bit_num,'0');
                                if(num_str == extend_bit)
                                {
                                    length = it[0]+i;
                                    break;
                                }
                                num++;
                            }
                        }
                        else
                        {
                            throw new Exception(ERROR_PARSE);
                        }
                        if (length == -1)
                        {
                            throw new Exception(ERROR_PARSE);
                        }
                    }
                    
                    var distance = -1;
                    { 
                        var distance_code = result.list_distance_code.First();
                        if(distance_code >= MAP_DISTANCE.Length || distance_code < 0)
                        {
                            throw new Exception(ERROR_PARSE);
                        }
                        var it = MAP_DISTANCE[distance_code];
                        if (it.Length == 1)
                        {
                            distance = it[0];
                        }
                        else if (it.Length == 3) {
                            var bit_num = it[2];
                            var extend_bit = result.list_distance_extend_code.First();
                            if(string.IsNullOrEmpty(extend_bit) || extend_bit.Length != bit_num)
                            {
                                throw new Exception(ERROR_PARSE);
                            }
                            var num = 0;
                            for (var i = 0; i <= it[1]-it[0]; i++)
                            {
                                var num_str = Convert.ToString(i,2).PadLeft(bit_num,'0');
                                if(num_str == extend_bit)
                                {
                                    distance = it[0]+i;
                                    break;
                                }
                                num++;
                            }
                        }
                        else
                        {
                            throw new Exception(ERROR_PARSE);
                        }

                        if (distance == -1)
                        {
                            throw new Exception(ERROR_PARSE);
                        }
                    }
                    builder.Append(encoding.GetString(buffer.ToArray()));
                    buffer.Clear();
                    builder.Append(builder.ToString().Substring(builder.Length-distance, length));
                    result.list_distance_code.RemoveAt(0);
                    result.list_distance_extend_code.RemoveAt(0);
                    result.list_literal_extend_code.RemoveAt(0);
                }
                else
                {
                    break;
                }
            }
            if(buffer.Any())
            {
                builder.Append(encoding.GetString(buffer.ToArray()));
                buffer.Clear();
            }
            return builder.ToString();
        }
        public class Result
        {
            public readonly List<int> list_literal_code;
            public readonly List<string> list_literal_extend_code;
            public readonly List<int> list_distance_code;
            public readonly List<string> list_distance_extend_code;

            public Result(List<int> list_literal_code, List<string> list_literal_extend_code, List<int> list_distance_code, List<string> list_distance_extend_code)
            {
                this.list_literal_code = list_literal_code;
                this.list_literal_extend_code = list_literal_extend_code;
                this.list_distance_code = list_distance_code;
                this.list_distance_extend_code = list_distance_extend_code;
            }
        }
    }
}
