﻿using System.Text;

namespace ConsoleApp
{
    public class DeflateHelper
    {
        public static byte[] compress(string input,Encoding encoding) {
            /**
             * [ZIP压缩算法详细分析及解压实例解释](https://www.cnblogs.com/esingchan/p/3958962.html)
             ** PK对于Deflate算法实现的思路:
             *** (1) 使用LZ77算法对输入内容进行编码,编码完成输出(literal,distance)
             *** (2) 对LZ77编码结果进行哈夫曼编码,编码完成输出bits1,bits2, 以及对应两颗码树
             *** (3) PK限定这两颗码树码长最长不超过15, 但实际测试往往会有超过15的情况, 后面在[动态哈夫曼编码分析](https://blog.csdn.net/jison_r_wang/article/details/52075870)
             *** 这篇文章中了解到对于深度超过15部分的分枝源码是进行了截枝,然后接到深度不满足15的分支上并且保证接入之后深度也要不超过15
             *** (4) 我们通过记录码长的方式来对这两颗码树进行压缩, 对应两个数组:int[286]&int[30],下标就是code,值就是码长
             *** 我们再对这两个数组进行游程编码, 编码后两个序列内任意值应该在0~18之间, 我们对这两个序列统计各自值出现的数字,合并后生成
             *** 哈夫曼表输出bits3,bits4; 同样我们再用记录码长的方式进行压缩, 压缩后码长应该在0~7之间, 这时我们就用3bit表示一个数即可
             *** (5) 结尾处还引用了一个置换的思想, 个人认为节省bit并不算多, 这里就不实现了
             */
            var result = LZ77Coding.encode(input,encoding);
            return default;
        }
        public static string uncompress(byte[] buffer) {
            return default;
        }
    }
}
