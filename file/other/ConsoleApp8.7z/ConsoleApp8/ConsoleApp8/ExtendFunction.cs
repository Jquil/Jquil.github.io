﻿using System.Collections.Generic;

namespace ConsoleApp
{
    public static class ExtendFunction
    {
        public static byte[] ToByteArray(this List<bool> list) {
            return default;
        }
        public static List<bool> Transform(this string code) { 
            var list = new List<bool>();
            foreach (var it in code.ToCharArray()) { 
                if(it == '0')
                {
                    list.Add(false);
                }
                else if(it == '1')
                {
                    list.Add(true);
                }
                else
                {
                    throw new System.Exception("transform failed!");
                }
            }
            return list;
        }
    }
}
