﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;

namespace ConsoleApp
{
    public class RLECoding
    {
        private readonly static int MAX_CODE_LENGTH = 20;
        private readonly static string ERROR_ENCODE = "encode failed";
        private readonly static string ERROR_DECODE = "decode failed";
        public static object[] encode(int[] array) {
            /**
             * 匹配结果为:0
             *   >> 匹配长度3<=x<=10的时候, 用22标识, 长度用3bit表示
             *   >> 匹配长度11<=x<=138的时候, 用23标识, 长度用7bit表示
             * 匹配结果为:≠0
             *   >> 匹配长度3<=x<=6的时候, 用21标识, 长度用2bit表示
             */
            if (!array.Any())
            {
                throw new ArgumentNullException(nameof(array));
            }
            var max = array.Max();
            if (max > MAX_CODE_LENGTH)
            {
                throw new ArgumentOutOfRangeException();
            }
            var list = new List<object>();
            var hismatch_list = new List<(int data,int index,bool match)>();
            hismatch_list.Add((-1,-1,false));
            for (var i = 0; i < array.Length; i++)
            {
                var it = array[i];
                if(hismatch_list.Last().data == -1)
                {
                    hismatch_list[hismatch_list.Count - 1] = (it,i,false); 
                }
                match(it,i);
            }
            (bool success, int data, int index, bool match) getLastPre() {
                (bool success, int data, int index, bool match) lastpre = (false, -1, -1, false);
                if (hismatch_list.Count != 1)
                {
                    var it = hismatch_list[hismatch_list.Count - 2];
                    lastpre = (true, it.data, it.index, it.match);
                }
                return lastpre;
            }
            void match(int data, int index)
            {
                var length = index - hismatch_list.Last().index;

                // lastpre用于判断在编码时是否需要输出当前数字
                var lastpre = getLastPre();

                if (hismatch_list.Last().data == data) {
                    if (data == 0) {
                        if(length == 138)
                        {
                            list.Add(MAX_CODE_LENGTH+3);
                            list.Add(Convert.ToString(127,2).PadLeft(7,'0'));
                            var last = hismatch_list.Last();
                            hismatch_list[hismatch_list.Count-1] = (last.data,last.index,true);
                            hismatch_list.Add((-1,-1,false));
                            return;
                        }
                    }
                    else {
                        length += 1;
                        if(length == 6)
                        {
                            if(lastpre.data != data)
                            {
                                list.Add(data);
                            }
                            list.Add(MAX_CODE_LENGTH + 1);
                            list.Add(Convert.ToString(3,2).PadLeft(2,'0'));
                            var last = hismatch_list.Last();
                            hismatch_list[hismatch_list.Count - 1] = (last.data, last.index, true);
                            hismatch_list.Add((-1, -1, false));
                            return;
                        }
                    }
                }
                else {
                    if(hismatch_list.Last().data == 0)
                    {
                        if (length >= 3 && length <= 10)
                        {
                            list.Add(MAX_CODE_LENGTH+2);
                            list.Add(Convert.ToString(length - 3,2).PadLeft(3,'0'));
                            var last = hismatch_list.Last();
                            hismatch_list[hismatch_list.Count - 1] = (last.data, last.index, true);
                        }
                        else if (length >= 11 && length <= 138)
                        {
                            list.Add(MAX_CODE_LENGTH + 3);
                            list.Add(Convert.ToString(length - 11, 2).PadLeft(7, '0'));
                            var last = hismatch_list.Last();
                            hismatch_list[hismatch_list.Count - 1] = (last.data, last.index, true);
                        }
                        else
                        {
                            for(var j = 0; j < length; j++)
                            {
                                list.Add(0);
                            }
                        }
                    }
                    else
                    {
                        if(length >= 3 && length <= 6)
                        {
                            if(!lastpre.success || (lastpre.match && lastpre.data != data))
                            {
                                list.Add(hismatch_list.Last().data);
                            }
                            list.Add(MAX_CODE_LENGTH+1);
                            list.Add(Convert.ToString(length-3,2).PadLeft(2,'0'));
                            var last = hismatch_list.Last();
                            hismatch_list[hismatch_list.Count - 1] = (last.data, last.index, true);
                        }
                        else
                        {
                            for (var j = 0; j < length; j++)
                            {
                                list.Add(hismatch_list.Last().data);
                            }
                        }
                    }
                    hismatch_list.Add((data, index, false));
                    return;
                }
            }
            if(hismatch_list.Last().index == array.Length - 1)
            {
                list.Add(hismatch_list.Last().data);
            }
            else
            {
                var length = array.Length - hismatch_list.Last().index;
                if(hismatch_list.Last().data == 0)
                {
                    if (length >= 3 && length <= 10)
                    {
                        list.Add(MAX_CODE_LENGTH + 2);
                        list.Add(Convert.ToString(length - 3, 2).PadLeft(3, '0'));
                        var last = hismatch_list.Last();
                        hismatch_list[hismatch_list.Count - 1] = (last.data, last.index, true);
                    }
                    else if (length >= 11 && length <= 138)
                    {
                        list.Add(MAX_CODE_LENGTH + 3);
                        list.Add(Convert.ToString(length - 11, 2).PadLeft(7, '0'));
                        var last = hismatch_list.Last();
                        hismatch_list[hismatch_list.Count - 1] = (last.data, last.index, true);
                    }
                    else
                    {
                        for (var j = 0; j < length; j++)
                        {
                            list.Add(0);
                        }
                    }
                }
                else
                {
                    var lastpre = getLastPre();
                    if(!lastpre.success || (lastpre.match && lastpre.data != hismatch_list.Last().data))
                    {
                        list.Add(hismatch_list.Last().data);
                    }
                    list.Add(MAX_CODE_LENGTH + 1);
                    list.Add(Convert.ToString(9 - length, 2).PadLeft(2, '0'));
                }
            }
            return list.ToArray();
        }
        public static int[] decode(object[] array) {
            var list = new List<int>();
            (int index, int data,int flag) match_info = (-1, -1,-1);
            for(var i = 0; i < array.Length; i++)
            {
                var it = array[i];
                if(it is int itint)
                {
                    if(itint == MAX_CODE_LENGTH + 1 || itint == MAX_CODE_LENGTH + 2 || itint == MAX_CODE_LENGTH + 3)
                    {
                        match_info.flag = itint;
                        match_info.index = i;
                        continue;
                    }
                    else
                    {
                        list.Add(itint);
                    }
                }
                else if (it is string itstr)
                {
                    if (match_info.flag != -1)
                    {
                        var length = Convert.ToInt32(itstr,2);
                        if(match_info.flag == MAX_CODE_LENGTH + 1)
                        {
                            length += 3;
                            var key = list.Last();
                            for(var j = 0; j < length; j++)
                            {
                                list.Add(key);
                            }
                        }
                        else if(match_info.flag == MAX_CODE_LENGTH + 2)
                        {
                            length += 3;
                            for(var j = 0; j < length; j++)
                            {
                                list.Add(0);
                            }
                        }
                        else if(match_info.flag == MAX_CODE_LENGTH + 3)
                        {
                            length += 11;
                            for (var j = 0; j < length; j++)
                            {
                                list.Add(0);
                            }
                        }
                        else
                        {
                            throw new Exception(ERROR_DECODE);
                        }
                        match_info.flag = -1;
                    }
                }
                else
                {
                    throw new Exception(ERROR_ENCODE);
                }
            }
            return list.ToArray();
        }
    }
}


/*
 
            var input = File.ReadAllText("D:\\《斗破苍穹》第一章.txt");
            var result = LZ77Coding.encode(input,System.Text.Encoding.UTF8);
            var code_map1 = HuffmanCoding.toMap(HuffmanCoding.encode(result.list_literal_code));
            var code_map2 = HuffmanCoding.toMap(HuffmanCoding.encode(result.list_distance_code));
            HuffmanCoding.serialize(code_map1, code_map2);
 */