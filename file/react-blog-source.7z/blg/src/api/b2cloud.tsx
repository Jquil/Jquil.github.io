import { BucketInfo,BucketUploadInfo } from '../model/b2cloud'
const _baseurl = "https://b2cloud.835292266.workers.dev"

export function getMarkdownBucketInfo(success:any){
    // this is md-jqwong.cn bucket
    const _credentials = "MDA0YTk4M2FlMTNmN2I3MDAwMDAwMDAwNTpLMDA0WlF1Y3NjTjNsU3BHUDQ4WDN4SHFnRy9aeWE0"
    fetch(_baseurl+"/b2api/v2/b2_authorize_account",{
        mode:'cors',
        headers:{
            "Authorization":`Basic ${_credentials}`
        }
    })
    .then(res => res.text())
    .then(res => {
        success(new BucketInfo(JSON.parse(res)))
    })
    .catch(error => {
        console.log(error)
    })
}

export function getBucketUploadUrl(bucketInfo:BucketInfo,success:any){
    bucketInfo.apiUrl = bucketInfo.apiUrl.replace("https://","")
    fetch(_baseurl+"/b2api/v2/b2_get_upload_url?apiUrl="+bucketInfo.apiUrl,{
        mode:'cors',
        method:'POST',
        headers:{
            "Authorization":bucketInfo.authorizationToken,
        },
        body:JSON.stringify({
            "bucketId":bucketInfo.allowed.bucketId
        })
    })
    .then(res=>res.text())
    .then(res=>{
        success(JSON.parse(res))
    })
    .catch(error=>{
        console.log(error)
    })
}


export function upload(uploadInfo:BucketUploadInfo,sha1:any,directory:any,file:any,success:any,error:any){
    let _uploadUrl = encodeURIComponent(uploadInfo.uploadUrl)
    fetch(`${_baseurl}/upload?uploadUrl=${_uploadUrl}`,{
        method:'POST',
        headers:{
            "Authorization":uploadInfo.authorizationToken,
            "X-Bz-File-Name":`${directory}/${file.name}`,
            "Content-Type":"text/plain",
            "X-Bz-Content-Sha1":sha1,
            "X-Bz-Info-Author":"unknown",
            "X-Bz-Server-Side-Encryption":"AES256"
        },
        body:file
    })
    .then(res => res.text())
    .then(res => {
        success()
        console.log(res)
    })
    .catch(err => {
        console.log(err)
        error(err)
    })
}
