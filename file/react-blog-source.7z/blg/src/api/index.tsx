export function manifest(call:any){
    fetch("/manifest.json?k="+Date.now())
    .then((res) => res.json())
    .then((data) => {
        call(data)
    })
    .catch(e => {
        console.log(e)
    })
}