import { User,Repo, RepoInfo, File } from '../model/github'

export function getUserInfo(token:string,username:string,call:any){
    fetch(`https://api.github.com/users/${username}`,{
        mode:'cors',
        headers:{
            "Authorization":"token "+token
        }
    })
    .then(res => res.text())
    .then(res => {
        var user = new User(JSON.parse(res))
        call(user)
    })
    .catch(e => {
        console.log(e)
    })
}


export function getRepos(token:string,repos_url:string,call:any){
    fetch(repos_url,{
        mode:'cors',
        headers:{
            "Authorization":"token "+token
        }
    })
    .then(res => res.text())
    .then(res => {
        var repos = new Array<Repo>(JSON.parse(res))
        call(repos[0])
    })
    .catch(e => {
        console.log(e)
    })
}


export function getRepoInfo(token:string,url:string,call:any){
    fetch(url,{
        mode:'cors',
        headers:{
            "Authorization":"token "+token
        }
    })
    .then(res => res.text())
    .then(res => {
        var repo = new RepoInfo(JSON.parse(res))
        call(repo)
    })
    .catch(e => {
        console.log(e)
    })
}

export function getRepoContent(token:string,contents_url:string,call:any){
    var _lastchar = contents_url.substring(contents_url.length-1)
    switch(_lastchar){
        case '/':
            contents_url = contents_url.substring(0,contents_url.length-1)
            break
    }
    var _random = "?r="+Date.now()
    if(contents_url.indexOf('?') !== -1){
        _random = "&r="+Date.now()
    }
    contents_url += _random
    fetch(contents_url,{
        mode:'cors',
        headers:{
            "Authorization":"token "+token
        }
    })
    .then(res => res.text())
    .then(res => {
        var files = new Array<File>(JSON.parse(res))
        call(files[0])
    })
    .catch(e => {
        console.log(e)
    })
}


export function upload(token:string,url:string,data: string,success:any,error:any){
    fetch(url,{
        mode:'cors',
        method:'PUT',
        headers:{
            'Content-Type':'application/json',
            "Authorization":"token "+token
        },
        body:JSON.stringify({
            "message":"new file",
            "content":data
        })
    })
    .then(res => res.text())
    .then(res => {
        success(res)
    })
    .catch(e => {
        error(e)
    })
}

export function deletef(token:string,file:File,success:any,error:any){
    // https://api.github.com/repos/Jquil/Jquil.github.io/contents/file/md/testupload.md
    fetch(file.url,{
        mode:'cors',
        method:'DELETE',
        headers:{
            'Content-Type':'application/json',
            "Authorization":"token "+token
        },
        body:JSON.stringify({
            "message":"delete file",
            "sha":file.sha
        })
    })
    .then(res => res.text())
    .then(res => {
        console.log(res)
        success(res)
    })
    .catch(e => {
        console.log(e)
        error(e)
    })
}