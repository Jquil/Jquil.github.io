class FileItem{
    
}