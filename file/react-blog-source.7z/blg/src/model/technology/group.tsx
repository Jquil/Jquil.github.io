import { TechnologyItem } from "./item"

export class TechnologyGroup{
    list:Array<TechnologyGroupItem>

    constructor(){
        this.list = new Array<TechnologyGroupItem>()
    }

    group(data:Array<TechnologyItem>){
        this.list = []
        data.forEach(item => {
            var year = item.date.substring(0,4)
            var group = this.list.find(g => g.year === year)
            if(group == null){
                group = new TechnologyGroupItem(year,new Array<TechnologyItem>())
                this.list.push(group)
            }
            group.list.push(item)
        })
    }

}

class TechnologyGroupItem{
    year:string
    list:Array<TechnologyItem>

    constructor(year:string,list:Array<TechnologyItem>){
        this.year = year
        this.list = list
    }
}