interface TechnologyItemDto{
    fileId:number;
    title:string;
    subTitle:string;
    imgUrl:string;
    tag:Array<string>;
    date:string;
}

export class TechnologyItem{
    fileId:number;
    title:string;
    subTitle:string;
    imgUrl:string;
    tag:Array<string>;
    date:string;

    constructor(dto:TechnologyItemDto){
        this.fileId = dto.fileId
        this.title = dto.title
        this.subTitle = dto.subTitle
        this.imgUrl = dto.imgUrl
        this.tag = dto.tag
        this.date = dto.date
    }
}
