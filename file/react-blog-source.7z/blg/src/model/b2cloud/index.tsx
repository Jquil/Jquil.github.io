interface BucketInfoDto{
    apiUrl:string,
    authorizationToken:string,
    allowed:{
        bucketId:string,
        bucketName:string
    }
}

interface BucketUploadInfoDto{
    authorizationToken:string,
    bucketId:string,
    uploadUrl:string
}

export class BucketInfo{
    apiUrl:string
    authorizationToken:string
    allowed:{
        bucketId:string,
        bucketName:string
    }

    constructor(dto:BucketInfoDto){
        this.apiUrl = dto.apiUrl
        this.authorizationToken = dto.authorizationToken
        this.allowed = dto.allowed
    }
}

export class BucketUploadInfo{
    authorizationToken:string
    bucketId:string
    uploadUrl:string

    constructor(dto:BucketUploadInfoDto){
        this.authorizationToken = dto.authorizationToken
        this.bucketId = dto.bucketId
        this.uploadUrl = dto.uploadUrl
    }
}