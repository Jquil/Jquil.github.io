interface UserDto{
    repos_url:string
}

interface RepoDto{
    name:string,
    url:string
}

interface RepoInfoDto{
    contents_url:string,
}

interface FileDto{
    name:string,
    path:string,
    sha:string,
    download_url:string,
    type:string,
    size:number,
    url:string,
}

export class User{
    repos_url:string

    constructor(dto:UserDto){
        this.repos_url = dto.repos_url
    }
}


export class Repo{
    url:string
    name:string
    constructor(dto:RepoDto){
        this.url = dto.url
        this.name = dto.name
    }
}

export class RepoInfo{
    contents_url:string
    constructor(dto:RepoInfoDto){
        this.contents_url = dto.contents_url
    }

}


export class File{
    name:string
    path:string
    sha:string
    download_url:string
    type:string
    size:number
    url:string

    constructor(dto:FileDto){
        this.name = dto.name
        this.path = dto.path
        this.sha = dto.sha
        this.download_url = dto.download_url
        this.type = dto.type
        this.size = dto.size
        this.url = dto.url
    }
}


export class Folder{
    url:string
    files:Array<File>

    constructor(url:string,files:Array<File>){
        this.url = url
        this.files = files
    }
}