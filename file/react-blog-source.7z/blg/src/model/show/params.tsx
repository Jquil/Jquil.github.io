export class ShowParams{
    prev?:LinkInfo
    next?:LinkInfo
    info:LinkInfo

    constructor(info:LinkInfo,prevInfo?:LinkInfo,nextInfo?:LinkInfo){
        this.info = info
        this.prev = prevInfo
        this.next = nextInfo
    }
}

export class LinkInfo{
    url:string
    title:string
    subtitle:string
    constructor(url:string,title:string,subtitle:string){
        this.url = url
        this.title = title
        this.subtitle = subtitle
    }
}