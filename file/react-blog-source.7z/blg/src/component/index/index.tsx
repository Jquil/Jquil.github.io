import {Component, ReactNode} from 'react'

export default class IndexComp extends Component{

    constructor(props:any){
        super(props)
        window.location.href = "https://www.github.com/Jquil"
    }

    render(): ReactNode {
        return (
            <div></div>
        )
    }
}