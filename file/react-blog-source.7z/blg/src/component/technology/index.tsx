import React from "react"
import {withRouter} from '../../router'
import {TechnologyItem}  from '../../model/technology/item'
import {TechnologyGroup} from '../../model/technology/group'
import {manifest} from '../../api'
import {LinkInfo} from "../../model/show/params"
import {StatusComp} from '../status'
import style from './index.module.css'

interface CompState{
    _baseurl_markdown:string,
    _data:TechnologyGroup
    _init:Boolean
    _loading:Boolean
    _error:string,
}

class TechnologyComp extends React.Component<any,CompState>{

    constructor(props:any){
        super(props)
        this.state = {
            _data:new TechnologyGroup(),
            _init:false,
            _baseurl_markdown:"",
            _loading: true,
            _error: ""
        }
    }

    render(): React.ReactNode {
        if(!this.state._init){
            this.readfile()
        }
        return (
            <StatusComp loading={this.state._loading}>
                <div>
                    <div className="site-title">
                        Technology
                    </div>
                    <div>
                        {
                            this.state._data.list.map(group => 
                                <div key={group.year}>
                                    <div className={style.year}>{group.year}</div>
                                    <ul className={style.list}>
                                        {group.list.map(item => 
                                            <li key={item.fileId}>
                                                <div className={style.title} onClick={(params) => this.jump(item)}>{item.title}</div>
                                                <div className={style.date}>{item.date.substring(5)}</div>
                                            </li>
                                        )}
                                    </ul>
                                </div>
                            )
                        }
                    </div>
                </div>
            </StatusComp>
        )
    }

    readfile(){
        manifest((json:any) => {
            this.setState({
                _baseurl_markdown: json.baseurl_markdown
            })
            var items = new Array<TechnologyItem>()
            fetch(json.technology_path)
            .then((res) => res.json())
            .then((data) => {
                data.data.forEach((element:any) => {
                    items.push(new TechnologyItem(element))
                })
                this.state._data.group(items)
                this.setState({
                    _init: true,
                    _loading:false,
                    _error:""
                })
            })
            .catch(e => {
                this.setState({
                    _init: true,
                    _loading:false,
                    _error:e
                })
            })
        })
    }

    jump(item:TechnologyItem){
        this.props.router.navigate("/s",{
            state:{
                info:new LinkInfo(`${this.state._baseurl_markdown}technology/${item.fileId}.md`,item.title,item.subTitle)
            }
        })
    }
}


export default withRouter(TechnologyComp)