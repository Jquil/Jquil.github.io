import React, { Component } from "react"
import { StatusComp } from "../status"
import { InboxOutlined,ExclamationCircleOutlined  } from '@ant-design/icons';
import { Modal,Select,Form,Upload, message } from 'antd'
import type { RcFile } from 'antd/es/upload'
import { getUserInfo, getRepos, getRepoInfo, getRepoContent,upload as upload2Github, deletef as deleteGitFile } from '../../api/github'
import { getMarkdownBucketInfo,getBucketUploadUrl,upload as B2Upload } from '../../api/b2cloud'
import { User as GitUser,Repo as GitRepo, RepoInfo as GitRepoInfo, File as GitFile, Folder as GitFolder } from '../../model/github'
import { BucketInfo as B2CloudBucketInfo,BucketUploadInfo as B2ClodBucketUploadInfo } from '../../model/b2cloud'
import style from './index.module.css'
import dirSvg  from './../../assets/svg/directory.svg'
import fileSvg from './../../assets/svg/file.svg'
import backSvg from './../../assets/svg/back.svg'
import Base64 from 'base-64'
import {manifest} from '../../api'


interface CompState{
    _githubToken:string,
    _init:Boolean
    _loading:Boolean
    _error:string,
    _gitBaseContentUrl:string,
    _path:string,
    _cmdOpen:boolean,
    _upload2B2Cloud:boolean,
    _folder:Array<GitFolder>
    _openDir:Array<GitFile>
    _files:Array<GitFile>
    _uploadFileList:Array<any>,
    _b2BucketUploadInfo?:B2ClodBucketUploadInfo,
    _b2UploadDirectory:string,
    _activeFile?:GitFile
}

const { Dragger } = Upload;

class FileComp extends Component<any,CompState>{

    constructor(props:any){
        super(props)
        this.state = {
            _githubToken:"",
            _loading:true,
            _error:"",
            _init:true,
            _gitBaseContentUrl: "",
            _folder:new Array<GitFolder>(),
            _openDir: new Array<GitFile>(),
            _files:new Array<GitFile>(),
            _path:"/",
            _cmdOpen:false,
            _upload2B2Cloud:false,
            _uploadFileList:new Array<any>(),
            _b2BucketUploadInfo:undefined,
            _b2UploadDirectory:"",
            _activeFile:undefined
        }
        console.log("ctrl&b to upload file")
    }

    componentDidMount(): void {
        this.registerEvent()
        this.initB2UploadInfo()
    }

    render(): React.ReactNode {
        if(this.state._gitBaseContentUrl === ""){
            // 对github-token base64，在字符串开头添加一位随机字符作为障眼法
            //console.log(Base64.encode("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"))
            manifest((json:any) => {
                let _token = Base64.decode(json.githubToken.substring(1))
                this.setState({
                    _githubToken: _token
                })
                this.initGitBaseContentUrl(_token,"Jquil",(url:string) => {
                    this.setState({
                        _gitBaseContentUrl: url
                    })
                    getRepoContent(_token,url,(files:Array<GitFile>) => {
                        this.state._folder.push(new GitFolder(url,files))
                        this.setState({
                            _files:files,
                            _loading:false
                        })
                    })
                })
            })
        }
        return (
            <StatusComp loading={this.state._loading}>
                <div>
                    <div className="site-title">
                        FileSystem
                    </div>
                    <div className={style.toolbar}>
                        { this.state._openDir.length===0?null:<img alt="" src={backSvg} className={style.back} onClick={() => this.back()}/> }
                        <span className={style.path}>{this.state._path}</span>
                    </div>
                    <div className={style.container}>
                        {
                            <div className={style.container}>
                            {
                                this.state._files.map(file => 
                                    <div key={file.sha} className={`${style.item} ${this.state._activeFile?.sha === file.sha ? style.item_active : style.item_default}`} onDoubleClick={(params)=> this.loadFile(file)} onClick={(params) => this.select(file)}>
                                        <img className={style.fileIcon} src={ file.type==="file"?fileSvg:dirSvg } alt=""/>
                                        <span className={style.fileName}>{file.name}</span>
                                    </div>
                                )
                            }
                        </div>
                        }
                    </div>
                    <Modal title="UPLOAD FILE" open={this.state._cmdOpen} onCancel={() => { this.setState({ _cmdOpen:false }) }} onOk={() => {this.uploadFile()}}>
                        <Form.Item label="Select upload type:">
                            <Select
                                defaultValue="github"
                                style={{ width: 120 }}
                                onChange={(v) => {this.handleUploadType(v)}}
                                options={[{ value: 'github', label: 'github' },{ value:'B2Cloud',label:'B2Cloud' }]}
                            />
                        </Form.Item>
                        { this.state._upload2B2Cloud ? <Form.Item label="Select upload directory:">
                            <Select
                                style={{ width: 120 }}
                                defaultValue="technology"
                                onChange={(value:string) => { this.setState({ _b2UploadDirectory:value }) }}
                                options={[{ value: 'technology', label: 'technology' },{ value:'note',label:'note' }]}
                            />
                        </Form.Item> : null }
                        <Dragger {...this.uploadFileProps} fileList={this.state._uploadFileList}>
                            <p className="ant-upload-drag-icon">
                                <InboxOutlined />
                            </p>
                            <p className="ant-upload-text">Click or drag file to this area to upload</p>
                            <p className="ant-upload-hint">
                                Support for a single or bulk upload. Strictly prohibited from uploading company data or other
                                banned files.
                            </p>
                        </Dragger>
                    </Modal>
                </div>
            </StatusComp>
        )
    }

    initGitBaseContentUrl(token:string,username:string,call:any){
        getUserInfo(token,username,(user:GitUser) => {
            getRepos(token,user.repos_url,(repos:Array<GitRepo>) => {
                repos.forEach(repo => {
                    if(repo.name === `${username}.github.io`){
                        getRepoInfo(token,repo.url,(repoInfo:GitRepoInfo) => {
                            let url = repoInfo.contents_url.replace("{+path}","")
                            call(url)
                        })
                        return
                    }
                })
            })
        })
    }

    initB2UploadInfo(){
        getMarkdownBucketInfo((bucketInfo:B2CloudBucketInfo) => {
            getBucketUploadUrl(bucketInfo,(bucketUploadInfo:B2ClodBucketUploadInfo)=>{
                this.setState({
                    _b2BucketUploadInfo:bucketUploadInfo
                })
            })
        })
    }

    loadFile(file:GitFile){
        if(file.type === "file"){
            file.download_url = file.download_url.replace("https://raw.githubusercontent.com/Jquil/Jquil.github.io/master","https://jqwong.cn")
            window.open(file.download_url)
            return
        }
        if(file.type === "dir"){
            this.state._openDir.push(file)
            let path = this.state._path + (this.state._path === "/" ? "" : "/") + file.name
            this.setState({
                _path:path
            })
            // 先从内存中找，没有再请求数据
            this.state._folder.forEach(item => {
                if(item.url === file.url){
                    this.setState({
                        _files:item.files
                    })
                    return
                }
            })
            getRepoContent(this.state._githubToken,file.url,(files:Array<GitFile>) => {
                this.state._folder.push(new GitFolder(file.url,files))
                this.setState({
                    _files:files
                })
                return
            })
        }
    }

    select(file:GitFile){
        if(this.state._activeFile?.sha === file.sha){
            this.setState({
                _activeFile:undefined
            })
        }
        else{
            this.setState({
                _activeFile: file
            })
        }
    }

    back(){
        this.state._openDir.pop()
        let path = this.state._path
        path = path.substring(0,path.lastIndexOf("/"))
        this.setState({
            _path:path === "" ? "/" : path
        })
        if(this.state._openDir.length === 0){
            this.setState({
                _files:this.state._folder[0].files
            })
        }
        else{
            var item = this.state._openDir[this.state._openDir.length-1]
            this.state._folder.forEach(folder => {
                if(folder.url === item?.url){
                    this.setState({
                        _files:folder.files
                    })
                    return
                }
            })
        }
    }

    registerEvent(){
        document.addEventListener('keydown',(e)=>{
            // ctrl+b
            if(e.ctrlKey && e.keyCode === 66){
                this.setState({
                    _cmdOpen:true
                })
            }

            if(e.keyCode === 46){
                this.deleteFile()
            }
        })
    }

    handleUploadType(value: string){
        value = value.toUpperCase()
        this.setState({
            _upload2B2Cloud: value === "B2CLOUD"
        })
    }

    uploadFileProps = {
        name: 'file',
        //action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
        onChange:this.handleUploadFileOnChange.bind(this),
        beforeUpload: (file:any) => {
            return false
        }
    }

    handleUploadFileOnChange(info:any){
        let newFileList = [...info.fileList]
        newFileList = newFileList.slice(-1)
        this.setState({
            _uploadFileList:newFileList
        })
    }

    uploadFile(){
        var file = this.state._uploadFileList.length === 0 ? null : this.state._uploadFileList[0]
        if(file === null)
            return
        
        if(this.state._upload2B2Cloud){
            this.uploadf2B2Cloud(file.originFileObj)
        }
        else{
            this.uploadf2Github(file.originFileObj)
        }
        this.setState({
            _cmdOpen:false
        })
    }

    uploadf2Github(file: RcFile){
        var key = Date.now()
        message.open({
            key,
            type: 'loading',
            content: 'uploading...',
          })
        var regEn = /[`~!@#$%^&*+<>?:"{},\/;'[\]]/im
	    var regCn = /[·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im
        if(regEn.test(file.name) || regCn.test(file.name)) {
            var _error = "The file name contains special characters"
            message.open({
                key,
                type: 'error',
                content: _error,
                duration: 10,
            })
            return
        }
        const reader = new FileReader()
        reader.readAsDataURL(file)
        var url = `${this.state._gitBaseContentUrl}${this.state._path.substring(1)}${this.state._path === '/' ? '' : '/'}${file.name}`
        var token = this.state._githubToken
        reader.onload = function () {
            var data = reader.result as string
            data = data.substring(data.indexOf(',')+1)
            upload2Github(token,url,data,
                ()=>{
                    message.open({
                        key,
                        type: 'success',
                        content: 'upload file to github success',
                        duration: 3,
                    })
                    setTimeout(() => {
                        window.location.reload()
                    },3000)
                },
                (e:any)=>{
                    message.open({
                        key,
                        type: 'error',
                        content: e,
                        duration: 10,
                    })
                }
            )
        }
        reader.onerror = function(){
            message.open({
                type: 'error',
                content: "read failed:" + reader.error,
                duration: 10,
            })
        }
    }

    uploadf2B2Cloud(file: RcFile){
        var _format = ".md"
        var key = Date.now()
        message.open({
            key,
            type: 'loading',
            content: 'uploading...',
          })
        if(file.name.substring(file.name.length-_format.length).toLowerCase() !== _format){
            var _msg = "sorry,upload file to b2clode only support mardowm format"
            message.open({
                key,
                type: 'error',
                content: _msg,
                duration: 10,
            })
            return
        }
        var _uploadInfo = this.state._b2BucketUploadInfo
        var _directory = this.state._b2UploadDirectory
        const reader = new FileReader()
        reader.readAsArrayBuffer(file)
        reader.onload = function () {
            (async function () {
                let sha1 = await crypto.subtle.digest('SHA-1', reader.result as ArrayBuffer).then(a => Array.from(new Uint8Array(a)).map(a => a.toString(16).padStart(2, '0')).join(""));
                B2Upload(_uploadInfo!!,sha1,_directory,file,
                ()=>{
                    message.open({
                        key,
                        type: 'success',
                        content: 'upload file to b2 success',
                        duration: 3,
                    })
                    setTimeout(() => {
                        window.location.reload()
                    },3000)
                },
                (e:any)=>{
                    message.open({
                        key,
                        type: 'error',
                        content: e,
                        duration: 10,
                    })
                })
            })();
        }
        reader.onerror = function(){
            message.open({
                type: 'error',
                content: "read failed:" + reader.error,
                duration: 10,
            })
        }
    }

    deleteFile(){
        if(this.state._activeFile === undefined){
            return
        }

        if(this.state._activeFile.type === "dir"){
            message.open({
                type: 'warning',
                content: 'Sorry, not support delete directory.',
            })
            return
        }

        var _file = this.state._activeFile!!
        var _token = this.state._githubToken
        Modal.confirm({
            title: 'Confirm',
            icon: <ExclamationCircleOutlined />,
            content: 'confirm delete this file?',
            okText: 'sure',
            cancelText: 'cancel',
            onOk(){
                var key = Date.now()
                message.open({
                    key,
                    type: 'loading',
                    content: 'deleting...',
                })
                deleteGitFile(_token,_file,
                    (res:any) => {
                        message.open({
                            key,
                            type: 'success',
                            content: 'delete file success',
                            duration: 3,
                        })
                        setTimeout(() => {
                            window.location.reload()
                        },3000)
                    },
                    (error:any) => {
                        message.open({
                            key,
                            type: 'error',
                            content: error,
                            duration: 10,
                        })
                    }
                )
            }
        })
    }
}


export default FileComp