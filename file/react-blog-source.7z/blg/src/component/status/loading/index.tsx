import React from "react"
import style from './index.module.css'

export class LoadingComp extends React.Component{
    render(): React.ReactNode {
        return (
            <div>
                <div className={style.loading}>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        )
    }
}