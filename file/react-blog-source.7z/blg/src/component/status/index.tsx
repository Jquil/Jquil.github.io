import React from "react"
import {LoadingComp} from './loading'

interface CompState{
    loading:boolean,
    error?:string,
}

export class StatusComp extends React.Component<any,CompState>{
    
    constructor(props:any){
        super(props)
        this.state = {
            loading:true,
            error:"",
        }
    }

    render(): React.ReactNode {
        return (
            <div>
                {this.state.loading?<LoadingComp />:null}
                {!this.state.loading && (this.state.error == null || this.state.error === "") ? this.props.children : null}
            </div>
        )
    }

    componentWillReceiveProps(nextProps:any){
        this.setState({
            loading:nextProps.loading,
            error:nextProps.error
        })
    }
}