import React, { Component } from "react";

class NoteComp extends Component{
    render(): React.ReactNode {
        return (
            <div>note</div>
        )
    }
}

export default NoteComp