import React from "react"
import ReactMarkdown  from "react-markdown"
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { darcula } from 'react-syntax-highlighter/dist/esm/styles/prism'
import Viewer from 'react-viewer'
import remarkGfm from 'remark-gfm'
import rehypeRaw from "rehype-raw"
import 'github-markdown-css'
import style from './index.module.css'
import { ShowParams } from "../../model/show/params"
import { withRouter } from "../../router"
import { ImageDecorator } from "react-viewer/lib/ViewerProps"
import { StatusComp } from "../status"

interface CompState{
    _params:ShowParams,
    _markdown:string,
    _init:boolean,
    _loading:boolean,
    _error:string,
    _viewerVisible:boolean,
    _viewerImages:ImageDecorator[],
    _viewerActiveIndex:number
}

class ShowComp extends React.Component<any,CompState>{

    constructor(prop:any){
        super(prop)
        let _state = this.props.router.location.state
        this.state = {
            _params: new ShowParams(_state.info,_state.prev,_state.next),
            _markdown: "",
            _init:false,
            _viewerVisible:false,
            _viewerImages:new Array<ImageDecorator>(),
            _viewerActiveIndex:0,
            _loading:true,
            _error:""
        }
    }

    render(): React.ReactNode {
        if(this.state._markdown === ""){
            this.readmarkdown()
        }
        return (
            <StatusComp loading={this.state._loading}>
                <div className={style.container}>
                    <div className={style.subtitle}>{this.state._params.info.subtitle}</div>
                    <div className={style.title}>{this.state._params.info.title}</div>
                    <div className="markdown-body">
                        <ReactMarkdown
                            components={{
                                code({node, inline, className, children, ...props}){
                                    const match = /language-(\w+)/.exec(className || '')
                                    return (
                                    !inline ? 
                                        <SyntaxHighlighter
                                            showLineNumbers={true}
                                            style={darcula}
                                            language={match!=null&&match.length >= 2? match[1] : null || ''}
                                            PreTag='div'
                                        >
                                            {String(children).replace(/\n$/, '')}
                                        </SyntaxHighlighter>
                                    :
                                    <code>{children}</code>
                                    )
                                }
                            }}
                            rehypePlugins={[rehypeRaw]}
                            remarkPlugins={[remarkGfm]}>
                                {this.state._markdown}
                        </ReactMarkdown>
                    </div>
                    <Viewer
                        activeIndex={this.state._viewerActiveIndex}
                        visible={this.state._viewerVisible}
                        images={this.state._viewerImages}
                        changeable={false}
                        onClose={() => {this.closeViewer()}}
                    />
                </div>
            </StatusComp>
        )
    }


    readmarkdown(){
        fetch(this.state._params.info.url,{
            mode:'cors'
        })
        .then(res => res.text())
        .then(text => {
            this.setState({
                _markdown:text,
                _init:true,
                _loading:false
            })
            this.registerViewerListener()
        })
        .catch(e => {
            console.log(e)
            this.setState({
                _loading:false,
                _error: e
            })
        })
    }


    async registerViewerListener(){
        setTimeout(() => {
            var dom = document.getElementsByClassName("markdown-body")
            if(dom == null || dom.length < 1)
                return
            var body = dom[0]
            var imgs = body.querySelectorAll("img")
            let arr = new Array<ImageDecorator>()
            imgs.forEach((node,index) => {
                arr.push({
                    src:node.getAttribute("src")||""
                })
                node.setAttribute("index",String(index))
                node.onclick = () => {
                    this.setState({
                        _viewerActiveIndex:Number(node.getAttribute("index")),
                        _viewerVisible:true
                    })
                }
            })
            this.setState({
                _viewerImages:arr
            })
        },1000)
    }


    closeViewer(){
        this.setState({
            _viewerVisible:false,
        })
    }
}

export default withRouter(ShowComp)