import React from "react"
class NotFoundComp extends React.Component{

    render(): React.ReactNode {
        return (
            <div>404</div>
        )
    }
}

export default NotFoundComp