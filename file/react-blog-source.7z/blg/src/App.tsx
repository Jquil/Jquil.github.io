import { Routes,Route } from 'react-router-dom'
import IndexComp from './component/index'
import TechnologyComp from './component/technology'
import ShowComp from './component/show'
import FileComp from './component/file'
import NoteComp from './component/note'
import NotFoundComp from './component/404'
import './App.css'

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/"  element={<IndexComp />} />
        <Route path="/t" element={<TechnologyComp />} />
        <Route path="/s" element={<ShowComp />} />
        <Route path="/f" element={<FileComp />} />
        <Route path="/n" element={<NoteComp />} />
        <Route path="*"  element={<NotFoundComp />} />
      </Routes>
    </div>
  );
}

export default App;
