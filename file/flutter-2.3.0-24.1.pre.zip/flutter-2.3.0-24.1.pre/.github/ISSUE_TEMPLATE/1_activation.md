---
name: I am having difficulty installing Flutter or getting it to work
about: You have run into problems while downloading or installing Flutter, or the
  "flutter" tool is crashing, or you are running into some other issue before even
  being able to use "flutter run".
title: ''
labels: ''
assignees: ''

---

<!-- Thank you for using Flutter!

     If you are looking for support, please check out our documentation
     or consider asking a question on Stack Overflow:
      * https://flutter.dev/
      * https://api.flutter.dev/
      * https://stackoverflow.com/questions/tagged/flutter?sort=frequent

     If you have found a bug or if our documentation doesn't have an answer
     to what you're looking for, then fill out the template below. Please read
     our guide to filing a bug first: https://flutter.dev/docs/resources/bug-reports
-->

## Steps to Reproduce

<!-- Please tell us exactly how to reproduce the problem you are running into. -->

1. ...
2. ...
3. ...

## Logs

<details>
<summary>Logs</summary>

<!--
      Include the full logs of the commands you are running between the lines
      with the backticks below. If you are running any "flutter" commands,
      please include the output of running them with "--verbose"; for example,
      the output of running "flutter --verbose create foo".
-->

```
```

<!-- If possible, paste the output of running `flutter doctor -v` here. -->

```
```

</details>
