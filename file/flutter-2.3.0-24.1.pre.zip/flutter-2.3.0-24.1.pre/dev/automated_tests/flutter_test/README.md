The files in this directory are used as part of the tests in the
`flutter_tools` package. Some are here because here these tests need a
`pubspec.yaml` that references the flutter framework (which is
intentionally not true of the `flutter_tools` package). Others are
here mostly out of peer pressure.