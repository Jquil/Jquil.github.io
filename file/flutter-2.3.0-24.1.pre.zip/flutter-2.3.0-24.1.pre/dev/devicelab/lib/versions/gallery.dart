// Copyright 2014 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/// The pinned version of flutter gallery, used for devicelab tests.
const String galleryVersion = 'aafbabc4d42e9a6e12899d269ecd1265e2fe4ba9';
