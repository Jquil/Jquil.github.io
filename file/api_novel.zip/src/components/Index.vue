<template>
    <div>
        200
    </div>
</template>

<script>
export default({
    name:"Index",
    methods:{
        
    },
    mounted(){
        this.$jsonp('https://www.sobiquge.com', {
        output: 'jsonp'
      }).then(res => {
        console.log(res)
      })
    }
})
</script>
