<template>
    <div>{{ json }}</div>
</template>

<script>
const cheerio = require('cheerio')
export default {
    name: 'SoftRes',
    data(){
        return{
            json: "",
            url:''
        }
    },
    methods:{
        get(url){
            this.$axios.get(`/api2${url}`)
            .then(res => {
                this.filter(res.data)
            })
        },
        filter(html){
            let $  = cheerio.load(html)
            let arr1 = [],arr2 = []

            let item = $(".item")
            for(let i = 0; i < item.length; i++){
                let temp = {}
                temp.title  = $(item)[i].children[1].children[0].children[1].attribs.alt
                temp.author = $(item)[i].children[3].children[1].children[0].children[0].data
                temp.url  = $(item)[i].children[1].children[0].attribs.href
                temp.pic  = $(item)[i].children[1].children[0].children[1].attribs.src
                temp.desc = $(item)[i].children[3].children[3].children[0].data
                console.log()
                arr1.push(temp)
            }


            let li = $(".l")[0].children[3].children
            for(let i = 0; i < li.length; i++){
                if(li[i].type == "text")
                    continue
                let temp = {}
                temp.title         = li[i].children[0].children[1].children[0].data
                temp.url           = li[i].children[0].children[1].attribs.href
                temp.author        = li[i].children[4].children[0].data
                temp.newestChapter = li[i].children[2].children[0].children[0].data
                arr2.push(temp)
            }
             let temp = {}
             temp.hot = arr1
             temp.new = arr2
             this.json = temp
        }
    },
    mounted(){
        let url   = this.$route.query.url
        this.url  = url
        this.get(url)
    },
    watch:{
        '$route':{
            handler(to){
                if(this.url != to.query.url){
                    this.url = to.query.url
                    this.get(this.url)
                }
            }
        }
    }
}
</script>