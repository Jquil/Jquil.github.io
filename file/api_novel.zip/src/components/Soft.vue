<template>
    <div>{{ json }}</div>
</template>

<script>
const cheerio = require('cheerio')
export default {
    name: 'Sort',
    data(){
        return{
            json:''
        }
    },
    methods:{
        get(){
            this.$axios.get('/api1/sort.html')
            .then(res => {
                this.filter(res.data)
            })
        },
        filter(html){
            let $ = cheerio.load(html)
            let li = $(".prev")
            let arr = []
            for(let i = 0; i < li.length; i++){
                let temp = {}
                temp.title = $(li)[i].children[0].children[0].data
                temp.url   = $(li)[i].children[0].attribs.href
                arr.push(temp)
            }
            this.json = JSON.stringify(arr)
        }   
    },
    created(){
        this.get()
    }
}
</script>