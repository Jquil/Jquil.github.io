<template>
    <div>{{ json }}</div>
</template>

<script>
const cheerio = require('cheerio')
export default {
    name: 'Content',
    data(){
        return{
            json:'',
            url:''
        }
    },
    methods:{
        get(url){
            if(url == "")
                return
            this.$axios.get(`/api2${url}`)
            .then(res => {
                this.filter(res.data)
            })
        },
        filter(html){
            let temp = {}
            let $ = cheerio.load(html)
            temp.title = $('.bookname')[0].children[1].children[0].data
            temp.content = $("#content").html()
            this.json = JSON.stringify(temp)
        }
    },
    mounted(){
            let url   = this.$route.query.url
            this.url  = url
            this.get(url)
    },
    watch:{
        '$route':{
            handler(to){
                if(this.url != to.query.url){
                    this.url = to.query.url
                    this.get(this.url)
                }
            }
        }
    }
}
</script>