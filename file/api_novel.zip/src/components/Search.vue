<template>
    <div>
        {{ json }}
    </div>
</template>

<script>
const cheerio = require('cheerio')
export default ({
    name: 'Search',
    data(){
        return{
            key:'',
            json:''
        }
    },
    methods:{
        search(key){
            this.$axios.get("/api1/search.php?q="+key)
            .then(res => {
                this.filter(res.data)
            })
        },
        filter(html){
            /*
             .result-game-item-title-link（title/link） √
             .result-game-item-desc（desc）√
             .result-game-item-info（author/type/newestChapter/newestTime）√
             .result-game-item-pic-link（pic）√
            */
            let $ = cheerio.load(html)
            let title = $(".result-game-item-title-link")
            let arr = []
            for(let i = 0; i < title.length; i++){
                let temp = {}
                temp.title = $(title[i])[0].attribs.title
                temp.url   = $(title[i])[0].attribs.href
                temp.desc  = $('.result-game-item-desc')[i].children[0].data

                let info = $(".result-game-item-info")[i]
                let tag  = $(info).find('.result-game-item-info-tag')
                temp.author        = tag[0].children[3].children[0].data
                temp.type          = tag[1].children[3].children[0].data
                temp.newestTime    = tag[2].children[3].children[0].data
                temp.newestChapter = tag[2].children[3].children[0].data
                temp.pic           = $('.result-game-item-pic-link')[i].children[1].attribs.src
                arr.push(temp)
            }
            this.json = JSON.stringify(arr)
        }
    },
    mounted(){
        let key = this.$route.query.key
        this.key = key
        this.search(key)
    },
    watch: {
        '$route':{
            handler(to){
                if(this.key != to.query.key){
                    this.key = to.query.key
                    this.search(this.key)
                }
            }
        }
    }
})
</script>
