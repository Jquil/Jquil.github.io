import Vue      from 'vue'
import Router   from 'vue-router'
import Index    from '../components/Index'
import Search   from '../components/Search'
import Chapters from '../components/Chapters'
import Content  from '../components/Content'
import Soft     from '../components/Soft'
import SoftRes  from '../components/SoftRes'

Vue.use(Router)

export default new Router({
    routes:[
        {
            path:'/',
            name:'index',
            component:Index
        },
        {
            path: '/search',
            name: 'search',
            component: Search
        },
        {
            path: '/chapters',
            name: 'chapters',
            component: Chapters
        },
        {
            path: '/content',
            name: 'content',
            component: Content
        },
        {
            path: '/soft',
            name: 'soft',
            component: Soft
        },
        {
            path: '/softres',
            name: 'softres',
            component: SoftRes
        }
    ]
})