module.exports = {
    lintOnSave: false,
    devServer:{
        port: 8080,
        proxy: {
            '/api1':{
              target:'https://m.sobiquge.com',
              changeOrigin:true,
              pathRewrite:{
                '^/api1': ''
              }
            },
            '/api2':{
              target:'https://www.sobiquge.com',
              changeOrigin:true,
              pathRewrite:{
                '^/api2': ''
              }
            }
        }
    }
}

// 分类：https://m.sobiquge.com/sort.html
// 搜索：https://m.sobiquge.com/search.php?q=%E4%B8%87%E7%9B%B8
// 书籍：https://www.sobiquge.com/book/23488/