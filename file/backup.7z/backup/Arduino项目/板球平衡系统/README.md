[1] [学会PID-基于板球平衡系统-初中基础就能听懂的简单讲](https://www.bilibili.com/video/BV1xL4y147ea)

[2] [通俗易懂的 PID 控制算法讲解](https://www.bilibili.com/video/BV1et4y1i7Gm)