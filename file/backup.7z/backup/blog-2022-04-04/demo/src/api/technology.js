import request from '@/utils/http'

export function getTechnologyAt(id){
    return request({
        url:`https://md.jqwong.cn/technology/${id}.md?r=${new Date().getTime()}`,
        method:'get'
    })
}

export function getTechnologyLs(){
    return request({
        url:'/static/data/technology.json',
        method:'get'
    })
}