<template>
    <div>
        <component :is="stateWidget" :loading="loading" :error="error"></component>
        <div v-if="!loading && !error">
            <header class="header">
                {{title}}
            </header>
            <span class="saying">{{saying}}</span>
            <div id="md" v-html="html"></div>
            <component :is="arrowWidget"></component>
        </div>
        <el-image-viewer
            v-if="showViewer"
            :initial-index="imgIndex"
            :on-close="closeViewer"
            :url-list="srcList">
        </el-image-viewer>
    </div>
</template>

<script>
import '../../../static/css/show.css'
import '../../../static/css/md.css'
import marked from '../../../static/js/marked'
import {getTechnologyAt} from '@/api/technology'
import ElImageViewer from 'element-ui/packages/image/src/image-viewer'
export default {
    components: { ElImageViewer },
    data(){
        return {
            loading:true,
            error:false,
            title:"",
            saying:"",
            html:"",
            showViewer:false,
            imgIndex:0,
            srcList:[],
            stateWidget: () => import("@/views/State"),
            arrowWidget: () => import("@/components/Arrow")
        }
    },
    methods:{
        compile(md){
            let html = marked(md)
            this.html = html
            this.filter()
            this.loading = false
        },
        filter(){
            setTimeout(() => {  
                // 设置行号  
                var pres = document.getElementsByTagName("pre")
                for(var i = 0; i < pres.length; i++){
                    let node = pres[i].childNodes[0]
                    if(node.nodeName == "CODE"){
                        let code = node.innerHTML
                        let list = code.split('\n')
                        list = list.map((item,index) => {
                            if(index == list.length-1)
                                return
                            return `<span class='line-number'>${index+1}</span>${item}`
                        })
                        node.innerHTML = list.join('\n')
                    }
                }
                
                // 设置图片可大图显示
                var imgs = document.getElementsByTagName("img")
                var _this = this
                for(var i = 0; i < imgs.length; i++){
                    this.srcList.push(imgs[i].getAttribute("src"))
                    imgs[i].index = i
                    imgs[i].onclick = function(){
                        _this.imgIndex = this.index
                        // 将index的那个图片放在第一位
                        //this.srcList = this.srcList.slice(_this.imgIndex).concat(this.srcList.slice(0, _this.imgIndex))
                        // 显示预览组件
                        _this.showViewer = true
                    }
                }
            },100)
        },
        getTech(id){
            var obj = this.$store.dispatch('technology/getTechById', id)
            obj.then(res => {
                if(res != null){
                    this.saying = res.subTitle
                    this.title = res.title
                }
            })
            getTechnologyAt(id)
            .then(res => {
                this.compile(res)
            })
            .catch(error => {
                console.log("发生错误")
            })
        },
        closeViewer(){
            this.showViewer = false
        }
    },
    mounted(){
        var query = this.$route.query
        switch(query.type){
            case "technology":
                this.getTech(query.id)
                break
        }
    }
}
</script>