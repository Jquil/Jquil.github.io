<template>
    <div>
        <component :is="stateWidget" :loading="loading" :error="error"></component>
        <div v-if="!loading && !error" class="flex">
            <img src="../../../static/img/avatar1.png" class="avatar"/>
            <span class="title bb">Jqwong's Blog</span>
            <div>
                <div class="year" v-for="item in this.tnLs" :key="item.year">
                    <div class="year-title">{{item.year}}</div>
                    <ul class="list">
                        <li v-for="tn in item.data" :key="tn.fileId">
                            <div class="at-title">
                                <router-link :to="{ name:'show',query:{ type:'technology',id:tn.fileId } }">{{tn.title}}</router-link>
                            </div>
                            <div class="at-date">{{tn.date.substring(5)}}</div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import '../../../static/css/home.css'
import {getTechnologyLs} from '@/api/technology'
export default {
    computed:{
        tnLs(){
            return this.$store.state.technology.tnLs
        }
    },
    data(){
        return {
            loading:false,
            error:false,
            stateWidget: () => import("@/views/State")
        }
    },
    created(){
        // todo
    },
    mounted(){
        if(this.tnLs.length == 0){
            getTechnologyLs().then(res => {
                this.$store.dispatch('technology/setTechnologyList', res.data)
                this.loading = false
            })
            .catch(error => {
                console.log(error)
                this.error = true
            })
        }
    }
}
</script>

