<template>
    <div>
        <div v-if="loading">
            <component :is="loadingWidget"></component>
        </div>
    </div>
</template>

<script>
export default {
    data(){
        return {
            loadingWidget: () => import("@/components/Loading")
        }
    },
    props:{
        loading:{
            type:Boolean
        },
        error:{
            type:Boolean
        }
    }
}
</script>