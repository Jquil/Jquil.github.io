import {groupBy} from '@/utils/group'

const state = {
    tnLs:[]
}

const mutations = {
    SET_TECHNOLOGY_LIST: (state,data) => {
        var arr = groupBy(data,item => {
            return item.date.substring(0,4)
        })
        for (let [key, value] of Object.entries(arr)) {
            state.tnLs.push({
                year:key.replaceAll("\"",""),
                data:value
            })
        }
    },

    GET_BYID:(state,id) => {
        
    }
}

const actions = {
    setTechnologyList({commit},data){
        commit("SET_TECHNOLOGY_LIST",data)
    },

    getTechById({commit},id){
        var res = null
        state.tnLs.forEach(obj => {
            obj.data.forEach(item => {
                if(item.fileId == id){
                    res = item
                    return
                }
            })
        })
        return new Promise(resolve => {
            resolve(res)
        })
    }
}

export default {
    namespaced: true,
    state,
    mutations,
    actions
}  