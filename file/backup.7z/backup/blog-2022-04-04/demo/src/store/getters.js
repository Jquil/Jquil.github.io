const getters = {
    tnLs: state => state.technology.tnLs,
  }
  export default getters
  