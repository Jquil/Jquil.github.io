<template>
    <div style="text-align:center;padding:10px;margin:20px 0 10px 0;cursor:pointer" @click="toTop">
        <svg t="1635313500485" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2400" xmlns:xlink="http://www.w3.org/1999/xlink" width="25" height="25">
            <path d="M576 234.688V1024H448V234.688L213.312 469.312 128 384l384-384 384 384-85.312 85.312L576 234.688z"
                 fill="#6d9ee7" p-id="2401"></path>
        </svg>
    </div>
</template>
<script>
export default {
    methods:{
        toTop:() => {
            document.body.scrollTop = document.documentElement.scrollTop = 0
        }
    }   
}
</script>