<template>
  <div id="app">
    <div class="max-width">
      <router-view/>
    </div>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>