import axios from 'axios'

const service = axios.create({
    //baseURL: "https://md.jqwong.cn",
    timeout: 5000 
})

service.interceptors.response.use(
    response => {
        return response.data
    },
    error => {
        console.log(error)
        return error
    }
)

export default service