后续使用到的套件：

【1】加载进度动画：npm install --save nprogress

【2】http请求组件：npm install axios

【3】状态管理：npm install vuex