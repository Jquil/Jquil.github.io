﻿namespace BT.UI
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmiAddDevice = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiDeleteDevice = new System.Windows.Forms.ToolStripMenuItem();
            this.batteryPanel1 = new BT.CustomControl.BatteryPanel();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.启动ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.停止ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.暂停ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.重置工艺ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.工艺续接ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // treeView1
            // 
            this.treeView1.ContextMenuStrip = this.contextMenuStrip1;
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Left;
            this.treeView1.Location = new System.Drawing.Point(10, 10);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(183, 443);
            this.treeView1.TabIndex = 0;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiAddDevice,
            this.tsmiDeleteDevice});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(125, 48);
            // 
            // tsmiAddDevice
            // 
            this.tsmiAddDevice.Name = "tsmiAddDevice";
            this.tsmiAddDevice.Size = new System.Drawing.Size(124, 22);
            this.tsmiAddDevice.Text = "添加设备";
            // 
            // tsmiDeleteDevice
            // 
            this.tsmiDeleteDevice.Name = "tsmiDeleteDevice";
            this.tsmiDeleteDevice.Size = new System.Drawing.Size(124, 22);
            this.tsmiDeleteDevice.Text = "删除设备";
            // 
            // batteryPanel1
            // 
            this.batteryPanel1.AutoScroll = true;
            this.batteryPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.batteryPanel1.Location = new System.Drawing.Point(193, 10);
            this.batteryPanel1.Name = "batteryPanel1";
            this.batteryPanel1.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.batteryPanel1.Size = new System.Drawing.Size(455, 443);
            this.batteryPanel1.TabIndex = 2;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.启动ToolStripMenuItem,
            this.停止ToolStripMenuItem,
            this.暂停ToolStripMenuItem,
            this.重置工艺ToolStripMenuItem,
            this.工艺续接ToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(181, 136);
            // 
            // 启动ToolStripMenuItem
            // 
            this.启动ToolStripMenuItem.Name = "启动ToolStripMenuItem";
            this.启动ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.启动ToolStripMenuItem.Text = "启动";
            // 
            // 停止ToolStripMenuItem
            // 
            this.停止ToolStripMenuItem.Name = "停止ToolStripMenuItem";
            this.停止ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.停止ToolStripMenuItem.Text = "停止";
            // 
            // 暂停ToolStripMenuItem
            // 
            this.暂停ToolStripMenuItem.Name = "暂停ToolStripMenuItem";
            this.暂停ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.暂停ToolStripMenuItem.Text = "暂停";
            // 
            // 重置工艺ToolStripMenuItem
            // 
            this.重置工艺ToolStripMenuItem.Name = "重置工艺ToolStripMenuItem";
            this.重置工艺ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.重置工艺ToolStripMenuItem.Text = "重置工艺";
            // 
            // 工艺续接ToolStripMenuItem
            // 
            this.工艺续接ToolStripMenuItem.Name = "工艺续接ToolStripMenuItem";
            this.工艺续接ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.工艺续接ToolStripMenuItem.Text = "工艺续接";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(658, 463);
            this.Controls.Add(this.batteryPanel1);
            this.Controls.Add(this.treeView1);
            this.Name = "frmMain";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.contextMenuStrip1.ResumeLayout(false);
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsmiAddDevice;
        private System.Windows.Forms.ToolStripMenuItem tsmiDeleteDevice;
        private CustomControl.BatteryPanel batteryPanel1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem 启动ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 停止ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 暂停ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 重置工艺ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 工艺续接ToolStripMenuItem;
    }
}