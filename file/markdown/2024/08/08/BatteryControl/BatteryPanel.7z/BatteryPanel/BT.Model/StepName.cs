﻿namespace BT.Model
{
    public enum StepName
    {
        恒流充电,
        恒压充电,
        恒流恒压充电,
        恒流放电,
        恒压放电,
    }
}
