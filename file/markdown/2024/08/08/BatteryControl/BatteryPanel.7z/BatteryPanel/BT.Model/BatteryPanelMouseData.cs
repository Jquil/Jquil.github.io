﻿using System.Drawing;

namespace BT.Model
{
    public class BatteryPanelMouseData
    {
        /// <summary>
        /// 是否按下Shift键
        /// </summary>
        public bool IsPressShift { get; set; }

        /// <summary>
        /// 鼠标左键按下的位置
        /// </summary>
        public Point LeftMouseDownPoint { get; set; }

        /// <summary>
        /// 鼠标右键按下的位置
        /// </summary>
        public Point RightMouseDownPoint { get; set; }

        /// <summary>
        /// 鼠标经过的位置
        /// </summary>
        public Point MouseMovePoint { get; set; }

        /// <summary>
        /// 滚动偏移量
        /// </summary>
        public Point AutoScrollPosition { get; set; }

        /// <summary>
        /// 框选区域
        /// </summary>
        public Rectangle FrameSelectionRect { get; set; }

        /// <summary>
        /// 重置
        /// </summary>
        public void Reset()
        {
            IsPressShift = false;
            LeftMouseDownPoint = Point.Empty;
            MouseMovePoint = Point.Empty;
            AutoScrollPosition = Point.Empty;
            FrameSelectionRect = Rectangle.Empty;
        }
    }
}
