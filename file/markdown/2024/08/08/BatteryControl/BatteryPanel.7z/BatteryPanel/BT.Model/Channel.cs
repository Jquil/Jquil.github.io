﻿namespace BT.Model
{
    public class Channel
    {
        /// <summary>
        /// 设备IP
        /// </summary>
        public string IP { get; set; }

        /// <summary>
        /// 设备号
        /// </summary>
        public int DeviceId { get; set; }

        /// <summary>
        /// 通道号
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// 电压
        /// </summary>
        public double Voltage { get; set; }

        /// <summary>
        /// 电流
        /// </summary>
        public double Current { get; set; }

        /// <summary>
        /// 功率
        /// </summary>
        public double Power => Voltage * Current;

        /// <summary>
        /// 温度
        /// </summary>
        public double Temperature;

        /// <summary>
        /// 工步名称
        /// </summary>
        public StepName Step { get; set; }
    }


}
