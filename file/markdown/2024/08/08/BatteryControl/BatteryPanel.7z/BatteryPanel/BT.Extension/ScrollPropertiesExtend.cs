﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BT.Extension
{
    public static class ScrollPropertiesExtend
    {
        /// <summary>
        /// 根据位移量正向移动
        /// </summary>
        /// <param name="offset">位移量</param>
        public static void MoveForward(this ScrollProperties scroll, int offset)
        {
            if (scroll.Value + offset < scroll.Maximum)
            {
                scroll.Value += offset;
            }
            else
            {
                scroll.Value = scroll.Maximum;
            }
        }

        /// <summary>
        /// 根据位移量反向移动
        /// </summary>
        /// <param name="offset">位移量</param>
        public static void MoveReverse(this ScrollProperties scroll, int offset)
        {
            if (scroll.Value - offset > scroll.Minimum)
            {
                scroll.Value -= offset;
            }
            else
            {
                scroll.Value = scroll.Minimum;
            }
        }
    }
}
