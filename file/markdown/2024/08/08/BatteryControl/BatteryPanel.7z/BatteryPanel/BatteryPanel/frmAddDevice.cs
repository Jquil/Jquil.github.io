﻿using BT.Data;
using BT.Model;
using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace BT.UI
{
    public partial class frmAddDevice : Form
    {
        private readonly string _title = "添加设备";

        private readonly Action<Device> _action;

        public frmAddDevice(Action<Device> action)
        {
            _action = action;

            InitializeComponent();

            RegisterEvents();
        }

        private void RegisterEvents()
        {
            btnOK.Click += BtnOK_Click;
        }

        private void BtnOK_Click(object sender, EventArgs args)
        {
            try
            {
                var text_ip = textBox1.Text;
                if(string.IsNullOrEmpty(text_ip))
                {
                    throw new Exception("IP不能为空");
                }
                var regex_ip = new Regex(@"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b");

                if (!regex_ip.IsMatch(text_ip))
                {
                    throw new Exception("IP无效");
                }

                var text_id = textBox2.Text;
                if (string.IsNullOrEmpty(text_id))
                {
                    throw new Exception("设备号不能为空");
                }
                if(!int.TryParse(text_id,out var devId))
                {
                    throw new Exception("设备号无效");
                }

                var device = new Device()
                {
                    IP = text_ip,
                    Id = devId
                };

                var result = DeviceBuffer.Instance.AddDevice(device);

                if(!result.Success)
                {
                    throw new Exception(result.Message);
                }

                _action?.Invoke(device);
                Close();
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message, _title);
            }
        }
    }
}
