﻿using System.Drawing;
using System.Windows.Forms;

namespace BT.Model
{
    public class BatteryPanelConfig
    {
        /// <summary>
        /// 列数
        /// </summary>
        public int ColNumber { get; set; }

        /// <summary>
        /// 字体
        /// </summary>
        public Font DrawFont { get; set; }

        /// <summary>
        /// 字体颜色
        /// </summary>
        public Color FontColor { get; set; }

        /// <summary>
        /// 通道大小
        /// </summary>
        public Size ChannelSize { get; set; }

        /// <summary>
        /// 通道内边距
        /// </summary>
        public Padding ChannelPadding { get; set; } 

        /// <summary>
        /// 通道外边距
        /// </summary>
        public Padding ChannelMargin { get; set; }

        /// <summary>
        /// 自动大小
        /// </summary>
        public bool AutoSize { get; set; }

        /// <summary>
        /// 默认配置
        /// </summary>
        public static BatteryPanelConfig Default => new BatteryPanelConfig()
        { 
            ColNumber = 5,
            DrawFont = new Font("宋体",10f),
            FontColor = Color.Black,
            ChannelSize = new Size(200,400),
            ChannelPadding = new Padding(5),
            ChannelMargin = new Padding(10),
            AutoSize = false,
        };
    }
}
