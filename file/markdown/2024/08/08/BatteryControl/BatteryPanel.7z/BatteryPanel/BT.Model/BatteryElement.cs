﻿using System.Drawing;

namespace BT.Model
{
    public class BatteryElement
    {
        /// <summary>
        /// 设备IP
        /// </summary>
        public string IP { get; set; }

        /// <summary>
        /// 设备号
        /// </summary>
        public int DevId { get; set; }

        /// <summary>
        /// 通道号
        /// </summary>
        public int ChannelId { get; set; }

        /// <summary>
        /// 矩形
        /// </summary>
        public Rectangle Rectangle { get; set; }

        /// <summary>
        /// 是否隐藏
        /// </summary>
        public bool Hide { get; set; }

        /// <summary>
        /// 工步名称
        /// </summary>
        public string StepName { get; set; }

        /// <summary>
        /// 内容区
        /// </summary>
        public string[] Content { get; set; }

        /// <summary>
        /// 背景颜色
        /// </summary>
        public Color Background { get; set; }

        /// <summary>
        /// 行高
        /// </summary>
        public int LineHeight { get; set; }

        /// <summary>
        /// 是否选中
        /// </summary>
        public bool IsSeleted { get; set; }

        /// <summary>
        /// 键
        /// </summary>
        public string Key => $"{IP}-{ChannelId}";
    }
}
