﻿using BT.Data;
using BT.Extension;
using BT.Logger;
using BT.Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BT.CustomControl
{
    public partial class BatteryPanel : Panel
    {
        /// <summary>
        /// 绘制时间
        /// </summary>
        private readonly int _drawTime = 500;

        /// <summary>
        /// 电极高度
        /// </summary>
        private readonly int _electrodeHeight = 20;

        /// <summary>
        /// 圆角半径
        /// </summary>
        private readonly int _radius = 15;

        /// <summary>
        /// 文字水平垂直居中
        /// </summary>
        private readonly StringFormat _stringCenter = new StringFormat()
        {
            LineAlignment= StringAlignment.Center,
            Alignment= StringAlignment.Center,
        };

        /// <summary>
        /// 滚动偏移量
        /// </summary>
        private readonly int _scrollOffset = 30;

        /// <summary>
        /// 右击事件
        /// </summary>
        private Action<string[],Point> _rightClickEvent;

        /// <summary>
        /// 绘制配置
        /// </summary>
        private BatteryPanelConfig _config = BatteryPanelConfig.Default;

        /// <summary>
        /// 绘制元素
        /// </summary>
        private List<BatteryElement> _elements = new List<BatteryElement>();

        /// <summary>
        /// 隐藏列表
        /// </summary>
        private List<string> _hideList = new List<string>();

        /// <summary>
        /// 上一次绘制时间
        /// </summary>
        private int _lastOnPaintTime = 0;

        /// <summary>
        /// 上一次绘制区大小
        /// </summary>
        private Size _lastDrawSize = Size.Empty;

        /// <summary>
        /// 鼠标信息
        /// </summary>
        private BatteryPanelMouseData _mouseData = new BatteryPanelMouseData();

        public BatteryPanel()
        {
            AutoScroll = true;

            Padding = new Padding(10,0,10,0);

            StartBackgroundTask();
        }

        protected override void OnPaint(PaintEventArgs args)
        {
            try
            {

                //var time = Environment.TickCount;

                base.OnPaint(args);

                var currentTime = Environment.TickCount;
                _lastOnPaintTime = currentTime;

                DrawChannels(args.Graphics, args.ClipRectangle);

                DrawMouseDragRect(args.Graphics);

                //Log.Information($"OnPaint, 耗时:{Environment.TickCount-time}ms");
            }
            catch(Exception e)
            {
                Log.Error(e.Message);
            }
        }

        private void DrawChannels(Graphics g, Rectangle clipRect)
        {
            // 处理线条锯齿
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // 处理文本锯齿
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;

            foreach (var element in _elements)
            {
                if (element.Hide)
                {
                    continue;
                }

                var location = new Point(AutoScrollPosition.X + element.Rectangle.X, AutoScrollPosition.Y + element.Rectangle.Y);
                var drawRect = new Rectangle(location.X,location.Y, element.Rectangle.Width, element.Rectangle.Height);

                if (clipRect.IntersectsWith(drawRect) || clipRect.Contains(location))
                {
                    using (var gP = new GraphicsPath())
                    {
                        // 绘制电池的路径
                        var position1 = new Point((int)(location.X + element.Rectangle.Width * 0.25), location.Y);
                        gP.AddArc(position1.X, position1.Y, _radius, _radius, 180, 90);
                        gP.AddArc(position1.X + ((int)(element.Rectangle.Width * 0.5) - _radius), position1.Y, _radius, _radius, 270, 90);
                        var position2 = new Point((int)(location.X + element.Rectangle.Width*0.75),location.Y);
                        gP.AddArc(position2.X,position2.Y+_electrodeHeight-_radius,_radius,_radius,180,-90);
                        var position3 = new Point(location.X + element.Rectangle.Width - _radius, location.Y+_electrodeHeight);
                        gP.AddArc(position3.X,position3.Y,_radius,_radius,270,90);
                        gP.AddArc(position3.X,location.Y+element.Rectangle.Height-_radius,_radius,_radius,0,90);
                        gP.AddArc(location.X,location.Y+element.Rectangle.Height-_radius,_radius,_radius,90,90);
                        gP.AddArc(location.X,location.Y+_electrodeHeight,_radius,_radius,180,90);
                        gP.AddArc(position1.X-_radius,location.Y+_electrodeHeight-_radius,_radius,_radius,90,-90);
                        gP.CloseAllFigures();

                        // 填充背景颜色
                        using (var brush = new SolidBrush(element.Background))
                        {
                            g.FillPath(brush, gP);
                        }

                        // 描边
                        if(element.IsSeleted)
                        {
                            using (var pen = new Pen(Color.Black, 3))
                            {
                                g.DrawPath(pen, gP);
                            }
                        }

                        // 填充文字
                        using(var brush = new SolidBrush(_config.FontColor))
                        {
                            var stringRect = new Rectangle(drawRect.X,drawRect.Y,drawRect.Width,_electrodeHeight+_radius);

                            // 电池编号
                            g.DrawString($"{element.DevId}-{element.ChannelId}", _config.DrawFont, brush, stringRect, _stringCenter);
                            stringRect.Y += _electrodeHeight;

                            // 工步名称
                            g.DrawString(element.StepName, _config.DrawFont, brush, stringRect, _stringCenter);
                            stringRect.Y += element.LineHeight + 12;

                            // 内容区
                            foreach(var it in element.Content)
                            {
                                g.DrawString(it, _config.DrawFont, brush, stringRect);
                                stringRect.Y += element.LineHeight + 3;
                            }
                        }
                    }
                }

            }
        }

        private void DrawMouseDragRect(Graphics g)
        {
            if (_mouseData.LeftMouseDownPoint != Point.Empty && _mouseData.MouseMovePoint != Point.Empty)
            {
                var downPoint = new Point(
                    _mouseData.LeftMouseDownPoint.X + _mouseData.AutoScrollPosition.X,
                    _mouseData.LeftMouseDownPoint.Y + _mouseData.AutoScrollPosition.Y
                );

                using (var brush = new SolidBrush(Color.FromArgb(80,170, 204, 238)))
                {
                    var minX = 0;
                    var width = 0;
                    if(downPoint.X < _mouseData.MouseMovePoint.X)
                    {
                        minX = downPoint.X;
                        width = _mouseData.MouseMovePoint.X - minX;
                    }
                    else
                    {
                        minX = _mouseData.MouseMovePoint.X;
                        width = downPoint.X - minX;
                    }

                    var minY = 0;
                    var height = 0;
                    if(downPoint.Y < _mouseData.MouseMovePoint.Y)
                    {
                        minY= downPoint.Y;
                        height = _mouseData.MouseMovePoint.Y - downPoint.Y;
                    }
                    else
                    {
                        minY = _mouseData.MouseMovePoint.Y;
                        height = downPoint.Y - _mouseData.MouseMovePoint.Y;
                    }

                    _mouseData.FrameSelectionRect = new Rectangle(minX, minY, width, height);

                    g.FillRectangle(brush, _mouseData.FrameSelectionRect);

                }
            }
        }

        public void SetConfig(BatteryPanelConfig config) => _config = config;

        public void StartBackgroundTask()
        {
            Task.Factory.StartNew(async () =>
            {
                while(true)
                {
                    try
                    {

                        //var time = Environment.TickCount;

                        // handle elements info
                        HandleElementsInfo();

                        // notify invalidate
                        if (Environment.TickCount - _lastOnPaintTime > _drawTime)
                        {
                            this.Invoke(new Action(() => this.Invalidate()));
                        }

                        //Log.Information($"BgTask耗时:{Environment.TickCount-time}ms");
                    }
                    catch (Exception e)
                    {
                        Log.Error(e.Message);
                    }

                    await Task.Delay(_drawTime);
                }
            });
        }

        private void HandleElementsInfo()
        {

            // 内容区行高
            var lineHeight = TextRenderer.MeasureText("测", _config.DrawFont).Height;

            if (_elements.Count() != RealDataBuffer.Instance.channels.Count())
            {
                _elements.Clear();
                foreach(var it in RealDataBuffer.Instance.channels)
                {
                    _elements.Add(new BatteryElement()
                    {
                        IP = it.Value.IP,
                        DevId = it.Value.DeviceId,
                        ChannelId = it.Value.Id,
                        Background = Color.Gray,
                        StepName = it.Value.Step.ToString()
                    });
                }
            }

            // 更新元素信息（X,Y，内容区）
            var element_size = _config.ChannelSize;
            if (_config.AutoSize)
            {
                // 电压电流温度功率 = 四行, 预留一行的空间
            }

            var x = Padding.Left;

            var y = Padding.Top;

            var colIndex = 0;

            var drawSize = Size.Empty;

            for(var i = 0; i < _elements.Count; i++)
            {
                var element = _elements[i];
                if (_hideList.Contains(element.IP))
                {
                    element.Hide = true;
                    continue;
                }
                element.Hide = false;

                element.Rectangle = new Rectangle(x,y,element_size.Width,element_size.Height);

                if (RealDataBuffer.Instance.channels.ContainsKey(element.Key))
                {
                    var channel = RealDataBuffer.Instance.channels[element.Key];
                    element.StepName = channel.Step.ToString();
                    element.Content = new string[]
                    {
                        $"电压:{Math.Round(channel.Voltage,2)}V",
                        $"电流:{Math.Round(channel.Current,2)}A",
                        $"功率:{Math.Round(channel.Power,2)}W",
                        $"温度:{Math.Round(channel.Temperature,2)}℃",
                    };
                    element.LineHeight = lineHeight;
                }

                colIndex++;
                if (colIndex == _config.ColNumber)
                {
                    colIndex = 0;
                    if (drawSize.Width == 0)
                    {
                        drawSize.Width = (x + element_size.Width + Padding.Right);
                    }

                    x = Padding.Left;
                    y += (element_size.Height + _config.ChannelMargin.Top);
                }
                else
                {
                    x += (element_size.Width + _config.ChannelMargin.Left);
                }

                drawSize.Height = (y + Padding.Bottom);
            }

            if(drawSize != _lastDrawSize)
            {
                this.Invoke(new Action(() =>
                {
                    AutoScrollMinSize = drawSize;
                }));
                _lastDrawSize = drawSize;
            }
        }

        public void DisplayBy(params string[] displaies)
        {
            _hideList.Clear();

            foreach(var it in DeviceBuffer.Instance.Devices)
            {
                if (!displaies.Contains(it.IP))
                {
                    _hideList.Add(it.IP);
                }
            }
        }

        public void DisplayAll()
        {
            _hideList.Clear();
        }

        public void SetRightClickEvent(Action<string[],Point> e) => _rightClickEvent = e;

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);

            if (e.Button == MouseButtons.Left)
            {
                _mouseData.LeftMouseDownPoint = e.Location;
                _mouseData.IsPressShift = (Control.ModifierKeys & Keys.Shift) == Keys.Shift;

                //Log.Information($"OnMouseDown,{_mouseData.MouseDownPoint}");
            }
            else if(e.Button == MouseButtons.Right)
            {
                _mouseData.RightMouseDownPoint = e.Location;
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);

            if(e.Button == MouseButtons.Left && _mouseData.LeftMouseDownPoint != Point.Empty)
            {
                _mouseData.MouseMovePoint = e.Location;

                _mouseData.AutoScrollPosition = AutoScrollPosition;

                if (e.Location.Y > ClientRectangle.Height)
                {
                    // 向下
                    VerticalScroll.MoveForward(_scrollOffset);
                }
                else if (e.Location.Y < ClientRectangle.Y)
                {
                    // 向上
                    VerticalScroll.MoveReverse(_scrollOffset);
                }
                else if (e.Location.X > ClientRectangle.Width)
                {
                    // 向右
                    HorizontalScroll.MoveForward(_scrollOffset);
                }
                else if (e.Location.X < ClientRectangle.X)
                {
                    // 向左
                    HorizontalScroll.MoveReverse(_scrollOffset);
                }
                else
                {
                    // 工作区内不处理
                }

                Invalidate();
            }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);

            if(_mouseData.LeftMouseDownPoint != Point.Empty)
            {
                var isFrameSelection = !_mouseData.IsPressShift && _mouseData.FrameSelectionRect != Rectangle.Empty;

                Parallel.ForEach(_elements, element =>
                {
                    var location = new Point(AutoScrollPosition.X + element.Rectangle.X, AutoScrollPosition.Y + element.Rectangle.Y);
                    var drawRect = new Rectangle(location.X, location.Y, element.Rectangle.Width, element.Rectangle.Height);

                    if (isFrameSelection)
                    {
                        element.IsSeleted = _mouseData.FrameSelectionRect.Contains(drawRect) || _mouseData.FrameSelectionRect.IntersectsWith(drawRect);
                    }
                    else
                    {
                        if (drawRect.Contains(_mouseData.LeftMouseDownPoint))
                        {
                            element.IsSeleted = !element.IsSeleted;
                        }
                        else
                        {
                            if (element.IsSeleted && _mouseData.IsPressShift)
                            {

                            }
                            else
                            {
                                element.IsSeleted = false;
                            }
                        }
                    }
                });

                Invalidate();
            }
            else if(_mouseData.RightMouseDownPoint != Point.Empty)
            {
                if (_rightClickEvent != null)
                {
                    var keys = new List<string>();
                    lock (_elements)
                    {
                        foreach(var element in _elements)
                        {
                            if(element.IsSeleted)
                            {
                                keys.Add(element.Key);
                            }
                        }
                    }

                    if (keys.Any())
                    {
                        _rightClickEvent.Invoke(keys.ToArray(),_mouseData.RightMouseDownPoint);
                    }
                }
            }

            _mouseData.Reset();
        }

        /// <summary>
        /// 解决页面频繁刷新时界面闪烁问题
        /// </summary>
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams createParams = base.CreateParams;
                createParams.ExStyle |= 0x02000000;
                return createParams;
            }
        }
    }
}