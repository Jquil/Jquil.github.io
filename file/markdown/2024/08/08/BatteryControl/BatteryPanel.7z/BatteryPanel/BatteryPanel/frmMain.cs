﻿using BT.Data;
using BT.Model;
using System;
using System.Windows.Forms;

namespace BT.UI
{
    public partial class frmMain : Form
    {
        private readonly string text_root = "设备列表";

        public frmMain()
        {
            InitializeComponent();

            RegisterEvents();

            InitDataSource();
        }

        private void RegisterEvents()
        {
            tsmiAddDevice.Click += TsmiAddDevice_Click;
            tsmiDeleteDevice.Click += TsmiDeleteDevice_Click;
            treeView1.NodeMouseClick += TreeView1_NodeMouseClick;
            batteryPanel1.SetRightClickEvent((keys,point) =>
            {
                contextMenuStrip2.Show(batteryPanel1, point);
            });
        }

        private void InitDataSource()
        {
            treeView1.Nodes.Add(text_root);

            RealDataBuffer.Instance.StartUpdateData();
        }

        private void TsmiAddDevice_Click(object sender, EventArgs e)
        {
            new frmAddDevice((device) =>
            {
                var node = treeView1.Nodes[0].Nodes.Add($"{device.IP}[{device.Id}]");
                node.Tag = device;
                treeView1.Nodes[0].ExpandAll();
                batteryPanel1.Invalidate();
            }).ShowDialog();
        }

        private void TsmiDeleteDevice_Click(Object sender, EventArgs e)
        {
            var node = treeView1.SelectedNode;
            if (node == null) return;
            if (node.Tag == null) return;
            if (!(node.Tag is Device device)) return;
            var result = DeviceBuffer.Instance.RemoveDevice(device);
            if(result.Success)
            {
                node.Remove();
                treeView1.SelectedNode = treeView1.Nodes[0];
                batteryPanel1.DisplayAll();
            }
            else
            {
                MessageBox.Show(result.Message, "删除设备");
            }
        }

        private void TreeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if(e.Node == null) return;
            if(e.Node.Text == text_root)
            {
                batteryPanel1.DisplayAll();
                return;
            }
            if(e.Node.Tag == null) return;
            if (!(e.Node.Tag is Device device)) return;
            batteryPanel1.DisplayBy(device.IP);
        }
    }
}
