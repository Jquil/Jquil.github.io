﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.Logger
{
    public class Log
    {
        public static void Information(string message)
        {
            Console.WriteLine($"{DateTime.Now}|Information|{message}");
        }
        public static void Error(string message)
        {
            Console.WriteLine($"{DateTime.Now}|Error|{message}");
        }
    }
}
