﻿using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Input;
using WPFDemo.Model;

namespace WPFDemo.Command
{
    public class OpenFileCommand : ICommand
    {
        private readonly Action<Result> _executed;
        private readonly Func<bool> _canExecute;

        public OpenFileCommand(Action<Result> executed, Func<bool> canExecute)
        {
            _executed = executed;
            _canExecute = canExecute;
        }

        public event EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }

            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        public bool CanExecute(object parameter)
        {
            if (_canExecute != null)
            {
                return _canExecute();
            }
            return false;
        }

        public void Execute(object parameter)
        {
            try
            {
                if(parameter!=null&&parameter is string path)
                {
                    if (File.Exists(path))
                    {
                        Process.Start(path);
                        _executed?.Invoke(new Result()
                        {
                            Success = true,
                        });
                    }
                    else
                    {
                        _executed?.Invoke(new Result()
                        {
                            Success = false,
                            Message = "找不到文件"
                        });
                    }
                }
            }
            catch(Exception e)
            {
                _executed?.Invoke(new Result()
                {
                    Success = false,
                    Message = e.Message,
                });
            }
        }
    }
}