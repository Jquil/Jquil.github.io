﻿using System;
using System.Collections.ObjectModel;
using WPFDemo.Model;

namespace WPFDemo.ViewModel
{
    public class MainViewModel : ObservableObject
    {
        public ObservableCollection<DownloadTask> DownloadTasks { get; set; }

        public Result RemoveTask(Guid guid)
        {
            try
            {
                for(var i = DownloadTasks.Count - 1; i>= 0; i--)
                {
                    if (DownloadTasks[i].Id == guid)
                    {
                        DownloadTasks.RemoveAt(i);
                        return new Result()
                        {
                            Success = true,
                        };
                    }
                }
                return new Result()
                {
                    Success = false,
                    Message = $"没有找到Id={guid}的下载任务"
                };
            }
            catch(Exception e)
            {
                return new Result()
                {
                    Success=false,
                    Message=e.Message
                };
            }
        }
    }
}