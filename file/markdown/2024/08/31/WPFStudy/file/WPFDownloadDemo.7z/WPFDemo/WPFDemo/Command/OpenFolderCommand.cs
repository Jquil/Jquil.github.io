﻿using System;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Input;
using WPFDemo.Logger;
using WPFDemo.Model;

namespace WPFDemo.Command
{
    public class OpenFolderCommand : ICommand
    {
        private readonly Func<bool> _canExecute;

        private readonly Action<Result> _executed;

        public OpenFolderCommand(Action<Result> executed, Func<bool> canExecute)
        {
            _executed = executed;
            _canExecute = canExecute;
        }

        event EventHandler ICommand.CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }

            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        bool ICommand.CanExecute(object parameter)
        {
            if(_canExecute != null)
            {
                return _canExecute();
            }
            return false;
        }

        void ICommand.Execute(object parameter)
        {
            try
            {
                if (parameter != null && parameter is string path)
                {
                    if (File.Exists(path))
                    {
                        Process.Start("explorer.exe", Path.GetDirectoryName(path));

                        _executed?.Invoke(new Result()
                        {
                            Success = true,
                        });
                    }
                    else
                    {
                        _executed?.Invoke(new Result()
                        {
                            Success = false,
                            Message = "文件不存在",
                        });
                    }
                }
            }
            catch (Exception e)
            {
                _executed?.Invoke(new Result()
                {
                    Success = false,
                    Message = e.Message,
                });
            }
        }
    }
}