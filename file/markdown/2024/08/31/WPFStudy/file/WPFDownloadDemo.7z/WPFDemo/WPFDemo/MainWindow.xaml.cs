﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using WPFDemo.Command;
using WPFDemo.Model;
using WPFDemo.ViewModel;

namespace WPFDemo
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly MainViewModel _model;

        public MainWindow()
        {
            InitializeComponent();

            _model = new MainViewModel()
            {
                DownloadTasks = new ObservableCollection<DownloadTask>()
            };

            this.DataContext = _model;

            Task.Factory.StartNew(async () =>
            {
                await Task.Delay(1000);

                var task = new DownloadTask(ShowErrorResultMessage,ShowErrorResultMessage, DeleteFileExecuted)
                {
                    Id = Guid.NewGuid(),
                    FilePath = "D://Downloads//test_file1.docx",
                    SuccessVisibility = Visibility.Collapsed,
                    RateVisibility = Visibility.Visible,
                    Downloading = true,
                };

                listbox.Dispatcher.Invoke(() => _model.DownloadTasks.Add(task));

                while (task.Rate != 100)
                {
                    listbox.Dispatcher.Invoke(() =>
                    {
                        task.Rate += 1;
                        task.Message = $"{task.Rate}%";
                    });

                    await Task.Delay(50);
                }
                listbox.Dispatcher.Invoke(() =>
                {
                    task.Success = true;
                    task.Downloading = false;
                });
            });

            Task.Factory.StartNew(async () =>
            {
                DownloadTask task = null;
                try
                {
                    await Task.Delay(1500);

                    task = new DownloadTask(ShowErrorResultMessage,ShowErrorResultMessage, DeleteFileExecuted)
                    {
                        Id = Guid.NewGuid(),
                        FilePath = "D://Downloads//test_file2.docx",
                        SuccessVisibility = Visibility.Collapsed,
                        RateVisibility = Visibility.Visible,
                        Downloading = true,
                    };

                    listbox.Dispatcher.Invoke(() => _model.DownloadTasks.Add(task));

                    while (task.Rate != 100)
                    {
                        listbox.Dispatcher.Invoke(() =>
                        {
                            task.Rate += 1;
                            task.Message = $"{task.Rate}%";
                        });

                        if (task.Rate == 50)
                        {
                            throw new Exception("模拟错误");
                        }

                        await Task.Delay(50);
                    }
                    listbox.Dispatcher.Invoke(() =>
                    {
                        task.Success = true;
                        task.Downloading = false;
                    });
                }
                catch (Exception e)
                {

                    if (task != null)
                    {
                        listbox.Dispatcher.Invoke(() =>
                        {
                            task.Success = false;
                            task.Message = e.Message;
                            task.Downloading = false;
                        });
                    }
                }
            });
        }

        private void ShowErrorResultMessage(Result result)
        {
            if(result != null)
            {
                if(!result.Success)
                {
                    MessageBox.Show(result.Message);
                }
            }
        }

        private void DeleteFileExecuted(Result<Guid> result)
        {
            if (result != null)
            {
                if (!result.Success)
                {
                    MessageBox.Show(result.Message);
                }
                else
                {
                    ShowErrorResultMessage(_model.RemoveTask(result.Data));
                }
            }
        }
    }
}