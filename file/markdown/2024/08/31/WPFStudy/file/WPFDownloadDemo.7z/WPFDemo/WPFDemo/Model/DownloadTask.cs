﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Input;
using WPFDemo.Command;

namespace WPFDemo.Model
{
    public class DownloadTask : ObservableObject
    {
        public DownloadTask(Action<Result> openFileExecuted, Action<Result> openFolderExecuted,Action<Result<Guid>> deleteFileExecuted)
        {
            OpenFileCommand = new OpenFileCommand(openFileExecuted, () => !downloading && success);
            OpenFolderCommand = new OpenFolderCommand(openFolderExecuted,() => !downloading&&success);
            DeleteFileCommand = new DeleteFileCommand((result) =>
            {
                var convert_result = new Result<Guid>()
                {
                    Success = result.Success,
                    Message = result.Message,
                };

                if (result.Success)
                {
                    convert_result.Data = Id;
                }

                deleteFileExecuted?.Invoke(convert_result);

            },() => !downloading&&success);
        }

        /// <summary>
        /// Id
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// 路径
        /// </summary>
        public string FilePath { get; set; }

        /// <summary>
        /// 进度
        /// </summary>
        private double rate
        {
            get; set;
        }

        /// <summary>
        /// 进度
        /// </summary>
        public double Rate
        {
            get { return rate; }
            set { rate = value; RaisePropertyChanged(); }
        }

        /// <summary>
        /// 提示消息
        /// </summary>
        private string message { get; set; }

        /// <summary>
        /// 提示信息
        /// </summary>
        public string Message
        {
            get => message;
            set { message = value; RaisePropertyChanged(); }
        }

        /// <summary>
        /// 是否下载中
        /// </summary>
        private bool downloading { get; set; }

        /// <summary>
        /// 是否下载中
        /// </summary>
        public bool Downloading
        {
            get => downloading;
            set { downloading = value; RaisePropertyChanged(); }
        }

        /// <summary>
        /// 是否成功
        /// </summary>
        private bool success { get; set; }

        /// <summary>
        /// 是否成功
        /// </summary>
        public bool Success
        {
            get { return success; }
            set
            {
                success = value;
                RaisePropertyChanged();

                if (success)
                {
                    RateVisibility = Visibility.Collapsed;
                    SuccessVisibility = Visibility.Visible;
                    CommandManager.InvalidateRequerySuggested();
                }
            }
        }

        /// <summary>
        /// 文件名称
        /// </summary>
        public string Name => Path.GetFileName(FilePath);

        /// <summary>
        /// 成功显示
        /// </summary>
        private Visibility successVisibility { get; set; }

        /// <summary>
        /// 成功显示
        /// </summary>
        public Visibility SuccessVisibility
        {
            get => successVisibility;
            set
            {
                successVisibility = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// 进度显示
        /// </summary>
        public Visibility rateVisibility { get; set; }

        /// <summary>
        /// 进度显示
        /// </summary>
        public Visibility RateVisibility
        {
            get => rateVisibility;
            set
            {
                rateVisibility = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// 打开文件夹命令
        /// </summary>
        public OpenFolderCommand OpenFolderCommand { get; set; }

        /// <summary>
        /// 删除文件命令
        /// </summary>
        public DeleteFileCommand DeleteFileCommand { get; set; }

        /// <summary>
        /// 打开文件命令
        /// </summary>
        public OpenFileCommand OpenFileCommand { get; set; }
    }
}