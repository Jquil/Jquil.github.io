﻿using System;

namespace WPFDemo.Logger
{
    internal class Log
    {
        public static void i(string message) => Console.WriteLine($"{DateTime.Now} {message}");
    }
}
