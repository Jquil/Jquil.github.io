﻿using CustomBatteryPanel.Data;
using CustomBatteryPanel.ViewModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace CustomBatteryPanel.View
{
    /// <summary>
    /// AddDeviceWindow.xaml 的交互逻辑
    /// </summary>
    public partial class AddDeviceWindow : Window
    {
        private readonly AddDeviceViewModel _model;

        public AddDeviceWindow()
        {
            InitializeComponent();

            _model = new AddDeviceViewModel()
            {
                Device = new Model.Device()
                {
                    IP = "192.168.110.1"
                }
            };

            this.DataContext = _model;
        }

        private void btn_close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void CmdSubmit_CanExecute(object sender, System.Windows.Input.CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = _model.IsValid;
        }

        private void CmdSubmit_Executed(object sender, System.Windows.Input.ExecutedRoutedEventArgs e)
        {
            var result = DeviceBuffer.Instance.AddDevice(_model.Device);
            if (result.Success)
            {
                Close();
            }
            else
            {
                MessageBox.Show(result.Message);
            }
        }
    }
}
