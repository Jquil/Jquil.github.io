﻿using CustomBatteryPanel.Data;
using CustomBatteryPanel.Logger;
using CustomBatteryPanel.Model;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace CustomBatteryPanel.CustomControl
{
    /// <summary>
    /// BatteryPanel.xaml 的交互逻辑
    /// </summary>
    public partial class BatteryPanel : ScrollViewer
    {
        /// <summary>
        /// 画布
        /// </summary>
        private readonly Canvas _ctx = new Canvas();

        /// <summary>
        /// 间隔时间
        /// </summary>
        private readonly int _interval = 500;

        /// <summary>
        /// 电极高度
        /// </summary>
        private readonly int _electrodeHeight = 23;

        /// <summary>
        /// 圆角半径
        /// </summary>
        private readonly int _radius = 8;

        /// <summary>
        /// 滚动偏移量
        /// </summary>
        private readonly int _scrollOffset = 15;

        /// <summary>
        /// 绘制元素
        /// </summary>
        private readonly List<BatteryElement> _elements = new List<BatteryElement>();

        /// <summary>
        /// 显示设备,[0]旧设备,[1]新设备
        /// </summary>
        private readonly string[] _displaies = new string[] { "","" };

        /// <summary>
        /// 上一次绘制区大小
        /// </summary>
        private Size _lastDrawSize = Size.Empty;

        /// <summary>
        /// 配置信息
        /// </summary>
        private BatteryPanelConfig _config = BatteryPanelConfig.Default;

        /// <summary>
        /// 鼠标信息
        /// </summary>
        private BatteryPanelMouseData _mouseData = new BatteryPanelMouseData();

        /// <summary>
        /// 取消信号
        /// </summary>
        private CancellationTokenSource _cts;

        /// <summary>
        /// 上一次绘制时间
        /// </summary>
        private int _lastPaintTime;

        /// <summary>
        /// 内边距
        /// </summary>
        private Thickness Padding = new Thickness(10);

        public BatteryPanel()
        {
            _ctx.HorizontalAlignment = HorizontalAlignment.Left;
            _ctx.VerticalAlignment = VerticalAlignment.Top;
            Content = _ctx;
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
            VerticalScrollBarVisibility= ScrollBarVisibility.Auto;
        }

        private void OnPaint(bool redraw)
        {
            if (!redraw && !_elements.Any())
                return;

            _lastPaintTime = Environment.TickCount;

            //Log.i("OnPaint");

            if (redraw)
            {
                _ctx.Children.Clear();
                var builder = new StringBuilder();
                foreach (var element in _elements)
                {
                    element.Container = new Path()
                    {
                        Fill = Brushes.Gray,
                    };

                    var centerX = element.Rectangle.X + element.Rectangle.Width / 2;

                    var endX = element.Rectangle.X + element.Rectangle.Width;

                    var endY = element.Rectangle.Y + element.Rectangle.Height;

                    var startX = element.Rectangle.X;

                    var startY = element.Rectangle.Y;

                    var width41 = element.Rectangle.Width / 4;

                    // 1
                    builder.Append($"M {centerX - width41},{element.Rectangle.Y + _radius} ");
                    builder.Append($"A {_radius},{_radius} 0 0 1 {centerX - width41 + _radius},{element.Rectangle.Y} ");

                    // 2
                    builder.Append($"L {centerX + width41 - _radius},{element.Rectangle.Y} ");
                    builder.Append($"A {_radius},{_radius} 0 0 1 {centerX + width41},{element.Rectangle.Y + _radius} ");

                    // 3
                    builder.Append($"L {centerX + width41},{element.Rectangle.Y + _electrodeHeight - _radius} ");
                    builder.Append($"A {_radius},{_radius} 0 0 0 {centerX + width41 + _radius},{element.Rectangle.Y + _electrodeHeight} ");

                    // 4
                    builder.Append($"L {endX - _radius},{element.Rectangle.Y + _electrodeHeight} ");
                    builder.Append($"A {_radius},{_radius} 0 0 1 {endX},{element.Rectangle.Y + _electrodeHeight + _radius} ");

                    // 5
                    builder.Append($"L {endX},{endY - _radius} ");
                    builder.Append($"A {_radius},{_radius} 0 0 1 {endX - _radius},{endY} ");

                    // 6
                    builder.Append($"L {startX + _radius},{endY} ");
                    builder.Append($"A {_radius},{_radius} 0 0 1 {startX},{endY - _radius}");

                    // 7
                    builder.Append($"L {startX},{startY + _electrodeHeight + _radius} ");
                    builder.Append($"A {_radius},{_radius} 0 0 1 {startX + _radius},{startY + _electrodeHeight} ");

                    // 8
                    builder.Append($"L {startX + width41 - _radius},{startY + _electrodeHeight} ");
                    builder.Append($"A {_radius},{_radius} 0 0 0 {startX + width41},{startY + _electrodeHeight - _radius} ");

                    builder.Append($"L {centerX - width41},{element.Rectangle.Y + _radius} Z");

                    element.Container.Data = Geometry.Parse(builder.ToString());

                    if (element.IsSeleted)
                    {
                        element.Container.Stroke = Brushes.Black;
                        element.Container.StrokeThickness = 1;
                    }
                    else
                    {
                        element.Container.StrokeThickness = 0;
                        element.Container.Stroke = Brushes.Transparent;
                    }

                    _ctx.Children.Add(element.Container);

                    // Label1 -> 设备ID-通道ID
                    element.labelKey = new Label()
                    {
                        VerticalContentAlignment = VerticalAlignment.Center,
                        HorizontalContentAlignment = HorizontalAlignment.Center,
                        Width = element.Rectangle.Width,
                        Height = _electrodeHeight,
                        Content = $"{element.DevId}-{element.ChannelId}",
                    };
                    Canvas.SetTop(element.labelKey, element.Rectangle.Y);
                    Canvas.SetLeft(element.labelKey, element.Rectangle.X);
                    _ctx.Children.Add(element.labelKey);


                    // Label1 -> 工步名称
                    element.labelStepName = new Label()
                    {
                        VerticalContentAlignment = VerticalAlignment.Center,
                        HorizontalContentAlignment = HorizontalAlignment.Center,
                        Width = element.Rectangle.Width,
                        Height = element.LineHeight + 3,
                        Content = element.StepName,
                        Padding = new Thickness(0),
                    };
                    Canvas.SetTop(element.labelStepName, element.Rectangle.Y + _electrodeHeight);
                    Canvas.SetLeft(element.labelStepName, element.Rectangle.X);
                    _ctx.Children.Add(element.labelStepName);

                    // TextBlock1 -> 实时数据
                    element.blockContent = new TextBlock()
                    {
                        Text = string.Join("\n", element.Content),
                        Padding = new Thickness(3, 0, 0, 0),
                        LineHeight = element.LineHeight + 6,
                    };
                    Canvas.SetTop(element.blockContent, element.Rectangle.Y + _electrodeHeight + element.LineHeight + 3);
                    Canvas.SetLeft(element.blockContent, element.Rectangle.X);
                    _ctx.Children.Add(element.blockContent);

                    builder.Clear();
                }
            }
            else
            {
                foreach (var element in _elements)
                {
                    element.labelStepName.Content = element.StepName;
                    element.blockContent.Text = string.Join("\n", element.Content);

                    if (element.IsSeleted)
                    {
                        element.Container.Stroke = Brushes.Black;
                        element.Container.StrokeThickness = 1;
                    }
                    else
                    {
                        element.Container.StrokeThickness = 0;
                        element.Container.Stroke = Brushes.Transparent;
                    }
                }
            }
        }

        public void Start()
        {
            _cts = new CancellationTokenSource();

            Task.Factory.StartNew(async () =>
            {
                while (!_cts.IsCancellationRequested)
                {
                    try
                    {
                        var redraw = HandleElementsInfo();

                        _ctx.Dispatcher.Invoke(() => OnPaint(redraw));

                        await Task.Delay(_interval);
                    }
                    catch (Exception e)
                    {
                        Log.e(e.Message);
                    }
                }
            });
        }

        private bool HandleElementsInfo()
        {

            var redraw = false;

            // 内容区行高
            var lineHeight = GetTextSize(this, "测", _config.FontSize, _config.DrawFont.Source).Height;

            if ((string.IsNullOrEmpty(_displaies[1]) && _elements.Count() != RealDataBuffer.Instance.channels.Count())
                || _displaies[0] != _displaies[1])
            {
                redraw = true;
                var cache_selected = new List<string>();
                foreach (var element in _elements)
                {
                    if (element.IsSeleted)
                    {
                        cache_selected.Add(element.Key);
                    }
                    element.Dispose();
                }
                _elements.Clear();

                foreach (var it in RealDataBuffer.Instance.channels)
                {
                    if (!string.IsNullOrEmpty(_displaies[1]) && _displaies[1] != it.Value.IP)
                    {
                        continue;
                    }
                    var element = (new BatteryElement()
                    {
                        IP = it.Value.IP,
                        DevId = it.Value.DeviceId,
                        ChannelId = it.Value.Id,
                        Background = System.Drawing.Color.Gray,
                        StepName = it.Value.Step.ToString()
                    });
                    if (cache_selected.Contains(element.Key))
                    {
                        element.IsSeleted = true;
                    }
                    _elements.Add(element);
                }
            }

            // 更新元素信息（X,Y，内容区）
            var element_size = _config.ChannelSize;
            if (_config.AutoSize)
            {
                // 电压电流温度功率 = 四行, 预留一行的空间
            }

            var x = Padding.Left;

            var y = Padding.Top;

            var colIndex = 0;

            var drawSize = new Size(0, 0);

            for (var i = 0; i < _elements.Count; i++)
            {
                var element = _elements[i];

                element.Rectangle = new Rect(x, y, element_size.Width, element_size.Height);

                if (RealDataBuffer.Instance.channels.ContainsKey(element.Key))
                {
                    var channel = RealDataBuffer.Instance.channels[element.Key];
                    element.StepName = channel.Step.ToString();
                    element.Content = new string[]
                    {
                        $"电压:{Math.Round(channel.Voltage,2)}V",
                        $"电流:{Math.Round(channel.Current,2)}A",
                        $"功率:{Math.Round(channel.Power,2)}W",
                        $"温度:{Math.Round(channel.Temperature,2)}℃",
                    };
                    element.LineHeight = (int)lineHeight;
                }

                colIndex++;
                if (colIndex == _config.ColNumber)
                {
                    colIndex = 0;
                    if (drawSize.Width == 0)
                    {
                        drawSize.Width = (x + element_size.Width + Padding.Right);
                    }

                    x = Padding.Left;
                    y += (element_size.Height + _config.ChannelMargin.Top);
                }
                else
                {
                    x += (element_size.Width + _config.ChannelMargin.Left);
                }

                drawSize.Height = (y + Padding.Bottom);
            }

            if (drawSize != _lastDrawSize)
            {
                Dispatcher.Invoke(new Action(() =>
                {
                    SetDrawSize(drawSize);
                }));

                _lastDrawSize = drawSize;

                return true;
            }

            _displaies[0] = _displaies[1];

            return redraw;
        }

        private void SetDrawSize(Size size)
        {
            _ctx.Width = size.Width;
            _ctx.Height = size.Height;
        }

        public void Stop()
        {
            _cts?.Cancel();
        }

        private Size GetTextSize(Visual visual, string text, double fontSize, string fontFamily)
        {
            var pixelsPerDip = VisualTreeHelper.GetDpi(visual).PixelsPerDip;
            FormattedText ft = new FormattedText(
                text,
                CultureInfo.CurrentCulture,
                FlowDirection.LeftToRight,
                new Typeface(fontFamily),
                fontSize,
                Brushes.Black,
                pixelsPerDip
            );
            return new Size(ft.Width, ft.Height);
        }

        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            base.OnMouseDown(e);

            if (e.LeftButton == MouseButtonState.Pressed)
            {
                _mouseData.IsPressLeftButton = true;
                var current_point = e.GetPosition(this);
                current_point.X += HorizontalOffset;
                current_point.Y += VerticalOffset;

                _mouseData.LeftMouseDownPoint = current_point;
                if ((Keyboard.Modifiers & ModifierKeys.Shift) == ModifierKeys.Shift)
                {
                    _mouseData.IsPressShift = true;
                }
            }

            OnPaint(false);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);

            if (_mouseData.IsPressLeftButton)
            {
                if (_mouseData.FrameSelectionRect == null)
                {
                    _mouseData.FrameSelectionRect = new Rectangle();

                    _mouseData.FrameSelectionRect.Fill = new SolidColorBrush(Color.FromArgb(80, 170, 204, 238));

                    Canvas.SetTop(_mouseData.FrameSelectionRect, _mouseData.LeftMouseDownPoint.Y);

                    Canvas.SetLeft(_mouseData.FrameSelectionRect, _mouseData.LeftMouseDownPoint.X);

                    _ctx.Children.Add(_mouseData.FrameSelectionRect);
                }

                var current_point = e.GetPosition(this);

                current_point.X += HorizontalOffset;
                current_point.Y += VerticalOffset;

                var width = current_point.X - _mouseData.LeftMouseDownPoint.X;
                var height = current_point.Y - _mouseData.LeftMouseDownPoint.Y;

                if (width < 0)
                {
                    Canvas.SetLeft(_mouseData.FrameSelectionRect, current_point.X);
                    width = Math.Abs(width);
                }

                if (height < 0)
                {
                    Canvas.SetTop(_mouseData.FrameSelectionRect, current_point.Y);
                    height = Math.Abs(height);
                }

                _mouseData.FrameSelectionRect.Width = width;

                _mouseData.FrameSelectionRect.Height = height;

                _mouseData.MouseMovePoint = e.GetPosition(this);

                var viewPortSize = new Size(ViewportWidth,ViewportHeight);

                var scrollOffset = new Size(HorizontalOffset,VerticalOffset);

                var distance = 10;

                var bottom = (viewPortSize.Height + scrollOffset.Height);

                var top = scrollOffset.Height;

                var left = scrollOffset.Width;

                var right = (viewPortSize.Width + scrollOffset.Width);

                if (bottom >= current_point.Y && (Math.Abs(bottom - current_point.Y)) < distance)
                {
                    // 向下滑动
                    MoveForward(ScrollDirection.V);
                }
                else if (current_point.Y >= top && (Math.Abs(top - current_point.Y)) < distance)
                {
                    // 向上滑动
                    MoveReverse(ScrollDirection.V);
                }
                else if (current_point.X >= left && (Math.Abs(left - current_point.X)) < distance)
                {
                    // 向左滑动
                    MoveReverse(ScrollDirection.H);
                }
                else if (current_point.X <= right && Math.Abs(right - current_point.X) < distance)
                {
                    // 向右滑动
                    MoveForward(ScrollDirection.H);
                }
            }
        }

        protected override void OnMouseUp(MouseButtonEventArgs e)
        {
            base.OnMouseUp(e);

            if (_mouseData.IsPressLeftButton)
            {
                var isFrameSelection = _mouseData.FrameSelectionRect != null;

                var frameRect = new Rect();

                if(isFrameSelection)
                {
                    frameRect.X = Canvas.GetLeft(_mouseData.FrameSelectionRect);
                    frameRect.Y = Canvas.GetTop(_mouseData.FrameSelectionRect);
                    frameRect.Width = _mouseData.FrameSelectionRect.Width;
                    frameRect.Height = _mouseData.FrameSelectionRect.Height;
                }

                Parallel.ForEach(_elements, element =>
                {
                    if (isFrameSelection)
                    {
                        element.IsSeleted = frameRect.Contains(element.Rectangle) || frameRect.IntersectsWith(element.Rectangle);
                    }
                    else
                    {
                        if (element.Rectangle.Contains(_mouseData.LeftMouseDownPoint))
                        {
                            element.IsSeleted = !element.IsSeleted;
                        }
                        else
                        {
                            if (element.IsSeleted && _mouseData.IsPressShift)
                            {

                            }
                            else
                            {
                                element.IsSeleted = false;
                            }
                        }
                    }
                });
            }

            if (_mouseData.FrameSelectionRect != null)
            {
                _ctx.Children.Remove(_mouseData.FrameSelectionRect);
            }

            _mouseData.Reset();

            OnPaint(false);
        }

        private void MoveForward(ScrollDirection direction)
        {
            if (direction == ScrollDirection.V)
            {
                ScrollToVerticalOffset(VerticalOffset + _scrollOffset);
            }
            else if (direction == ScrollDirection.H)
            {
                ScrollToHorizontalOffset(HorizontalOffset + _scrollOffset);
            }
        }

        private void MoveReverse(ScrollDirection direction)
        {
            if (direction == ScrollDirection.V)
            {
                ScrollToVerticalOffset(VerticalOffset - _scrollOffset);
            }
            else if (direction == ScrollDirection.H)
            {
                ScrollToHorizontalOffset(HorizontalOffset - _scrollOffset);
            }
        }

        public void DisplayBy(string ip)
        {
            _displaies[1] = ip;
        }

        public void DisplayAll()
        {
            _displaies[1] = string.Empty;
        }

        public IEnumerable<(string ip,int channel)> GetSelectedChannels()
        {
            lock (_elements)
            {
                foreach (var element in _elements)
                {
                    if(element.IsSeleted)
                    {
                        yield return (element.IP,element.ChannelId);
                    }
                }
            }
        }
    }
}