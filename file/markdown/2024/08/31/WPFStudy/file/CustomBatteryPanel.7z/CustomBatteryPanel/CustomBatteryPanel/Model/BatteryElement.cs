﻿using System;
using System.Drawing;
using System.Windows;
using System.Windows.Controls;

namespace CustomBatteryPanel.Model
{
    public class BatteryElement:IDisposable
    {
        /// <summary>
        /// 设备IP
        /// </summary>
        public string IP { get; set; }

        /// <summary>
        /// 设备号
        /// </summary>
        public int DevId { get; set; }

        /// <summary>
        /// 通道号
        /// </summary>
        public int ChannelId { get; set; }

        /// <summary>
        /// 矩形
        /// </summary>
        public Rect Rectangle { get; set; }

        /// <summary>
        /// 工步名称
        /// </summary>
        public string StepName { get; set; }

        /// <summary>
        /// 内容区
        /// </summary>
        public string[] Content { get; set; }

        /// <summary>
        /// 背景颜色
        /// </summary>
        public Color Background { get; set; }

        /// <summary>
        /// 行高
        /// </summary>
        public int LineHeight { get; set; }

        /// <summary>
        /// 是否选中
        /// </summary>
        public bool IsSeleted { get; set; }

        /// <summary>
        /// 键
        /// </summary>
        public string Key => $"{IP}-{ChannelId}";

        /// <summary>
        /// Label(设备号-通道号)
        /// </summary>
        public Label labelKey { get; set; }

        /// <summary>
        /// Label(工步名称)
        /// </summary>
        public Label labelStepName { get; set; }

        /// <summary>
        /// TextBlock(内容区)
        /// </summary>
        public TextBlock blockContent { get; set; }

        /// <summary>
        /// 通道外观
        /// </summary>
        public System.Windows.Shapes.Path Container { get; set; }

        public void Dispose()
        {
            Container = null;
            labelKey= null;
            labelStepName= null;
            blockContent= null;
        }
    }
}
