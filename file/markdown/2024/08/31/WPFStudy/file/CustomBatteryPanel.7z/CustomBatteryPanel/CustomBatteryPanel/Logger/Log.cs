﻿using System;

namespace CustomBatteryPanel.Logger
{
    public class Log
    {
        public static void i(string message) => Console.WriteLine($"{DateTime.Now}|INFO|{message}");
        public static void e(string message) => Console.WriteLine($"{DateTime.Now}|ERROR|{message}");
    }
}
