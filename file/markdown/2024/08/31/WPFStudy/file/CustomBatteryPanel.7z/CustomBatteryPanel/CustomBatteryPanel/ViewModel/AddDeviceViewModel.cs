﻿using CustomBatteryPanel.Model;
using CustomBatteryPanel.Rule;

namespace CustomBatteryPanel.ViewModel
{
    public class AddDeviceViewModel:ObservableObject,IValidationExceptionHandler
    {
        public Device Device { get; set; }
        private bool isValid { get; set; }
        public bool IsValid
        {
            get
            {
                return isValid;
            }
            set
            {
                isValid = value;
                RaisePropertyChanged();
            }
        }
    }
}