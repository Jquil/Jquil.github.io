﻿using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows.Controls;

namespace CustomBatteryPanel.Rule
{
    public class IPValidationRule : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            var pattern = "(([01]?[0-9]?[0-9])|(2[0-4][0-9])|(25[0-5]))\\.(([01]?[0-9]?[0-9])|(2[0-4][0-9])|(" +
            "25[0-5]))\\.(([01]?[0-9]?[0-9])|(2[0-4][0-9])|(25[0-5]))\\.(([01]?[0-9]?[0-9])|(2[" +
            "0-4][0-9])|(25[0-5]))";

            if(string.IsNullOrEmpty(value?.ToString()))
            {
                return new ValidationResult(false, "未填写内容");
            }

            if(value != null && Regex.Match(value.ToString(),pattern).Success)
            {
                return ValidationResult.ValidResult;
            }
            return new ValidationResult(false, "不符合IP规则");
        }
    }
}
