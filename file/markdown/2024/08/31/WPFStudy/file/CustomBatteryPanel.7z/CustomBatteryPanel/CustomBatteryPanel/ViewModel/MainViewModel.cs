﻿using CustomBatteryPanel.Data;
using CustomBatteryPanel.Model;
using System.Collections.ObjectModel;

namespace CustomBatteryPanel.ViewModel
{
    public class MainViewModel:ObservableObject
    {
        public ObservableCollection<Device> Devices => DeviceBuffer.Instance.Devices;
    }
}