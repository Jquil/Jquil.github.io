﻿using CustomBatteryPanel.Rule;
using Microsoft.Xaml.Behaviors;
using System;
using System.Windows;
using System.Windows.Controls;

namespace CustomBatteryPanel.Behaviors
{
    public class ValidationExceptionBehavior : Behavior<FrameworkElement>
    {
        /// <summary>
        /// 错误计数器
        /// </summary>
        private int _validationExceptionCount = 0;

        /// <summary>
        /// 附加对象时
        /// </summary>
        protected override void OnAttached()
        {
            this.AssociatedObject.AddHandler(Validation.ErrorEvent, new EventHandler<ValidationErrorEventArgs>(this.OnValidationError));
        }

        private void OnValidationError(object sender, ValidationErrorEventArgs arg)
        {
            try
            {
                if (this.AssociatedObject.DataContext is IValidationExceptionHandler)
                {
                    var handler = this.AssociatedObject.DataContext as IValidationExceptionHandler;

                    var element = arg.OriginalSource as UIElement;

                    if (handler == null || element == null)
                        return;

                    if (arg.Action == ValidationErrorEventAction.Added)
                    {
                        _validationExceptionCount++;

                    }
                    else if (arg.Action == ValidationErrorEventAction.Removed)
                    {
                        _validationExceptionCount--;
                    }

                    handler.IsValid = _validationExceptionCount == 0;
                }
                else
                {

                }
            }
            catch (Exception e)
            {
                // TODO
            }
        }
    }
}