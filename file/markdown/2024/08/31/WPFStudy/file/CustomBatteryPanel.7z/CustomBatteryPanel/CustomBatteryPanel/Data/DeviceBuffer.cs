﻿using CustomBatteryPanel.Model;
using System.Collections.ObjectModel;
using System.Linq;

namespace CustomBatteryPanel.Data
{
    public class DeviceBuffer
    {
        private static DeviceBuffer _instance;

        private readonly ObservableCollection<Device> _devices = new ObservableCollection<Device>();

        public ObservableCollection<Device> Devices => Instance._devices;

        private DeviceBuffer() { }

        public static DeviceBuffer Instance
        {
            private set { }
            get
            {
                if (_instance == null)
                {
                    _instance = new DeviceBuffer();
                }
                return _instance;
            }
        }

        public Result AddDevice(Device device)
        {
            foreach (var it in _devices)
            {
                if (it.IP == device.IP)
                {
                    return new Result()
                    {
                        Success = false,
                        Message = "设备已存在(IP)"
                    };
                }
                if (it.Id == device.Id)
                {
                    return new Result()
                    {
                        Success = false,
                        Message = "设备已存在(设备号)"
                    };
                }
            }
            _devices.Add(device);
            return new Result()
            {
                Success = true,
                Message = string.Empty
            };
        }

        public Result RemoveDevice(Device device)
        {
            for (var i = _devices.Count() - 1; i >= 0; i--)
            {
                var it = _devices[i];
                if (it.IP == device.IP)
                {
                    _devices.RemoveAt(i);

                    RealDataBuffer.Instance.RemoveChannelData(it);

                    return new Result()
                    {
                        Success = true,
                        Message = string.Empty
                    };
                }
            }
            return new Result()
            {
                Success = false,
                Message = $"没有找到IP为{device.IP}的设备"
            };
        }
    }
}