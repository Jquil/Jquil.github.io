﻿using CustomBatteryPanel.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomBatteryPanel.Data
{
    public class RealDataBuffer
    {
        private static RealDataBuffer _instance;

        private Dictionary<string, Channel> _channels = new Dictionary<string, Channel>();

        public Dictionary<string, Channel> channels => _channels;

        private RealDataBuffer()
        {

        }

        public static RealDataBuffer Instance
        {
            private set { }
            get
            {
                if (_instance == null)
                {
                    _instance = new RealDataBuffer();
                }
                return _instance;
            }
        }

        public void StartUpdateData()
        {
            Task.Factory.StartNew(async () =>
            {
                var random = new Random();
                while (true)
                {
                    lock (_channels)
                    {
                        foreach (var device in DeviceBuffer.Instance.Devices)
                        {
                            foreach (var chid in Enumerable.Range(0, 10))
                            {
                                var key = $"{device.IP}-{chid}";
                                if (_channels.ContainsKey(key))
                                {
                                    _channels[key].Voltage = random.NextDouble() * 100;
                                    _channels[key].Current = random.NextDouble() * 100;
                                    _channels[key].Temperature = random.NextDouble() * 10;
                                }
                                else
                                {
                                    _channels.Add(key, new Channel()
                                    {
                                        IP = device.IP,
                                        DeviceId = device.Id.Value,
                                        Id = chid,
                                        Voltage = random.NextDouble() * 100,
                                        Current = random.NextDouble() * 100,
                                        Temperature = random.NextDouble() * 10,
                                        Step = StepName.恒流充电
                                    });
                                }
                            }
                        }
                    }

                    await Task.Delay(500);
                }
            });
        }

        public void RemoveChannelData(Device device)
        {
            lock (_channels)
            {
                for (var i = _channels.Count() - 1; i >= 0; i--)
                {
                    var element = _channels.ElementAt(i);
                    if (element.Key.StartsWith($"{device.IP}-"))
                    {
                        _channels.Remove(element.Key);
                    }
                }
            }
        }
    }
}
