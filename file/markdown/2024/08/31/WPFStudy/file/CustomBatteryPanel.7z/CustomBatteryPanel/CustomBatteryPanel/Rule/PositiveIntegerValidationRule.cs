﻿using System.Globalization;
using System.Windows.Controls;

namespace CustomBatteryPanel.Rule
{
    public class PositiveIntegerValidationRule : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if (value == null || string.IsNullOrEmpty(value.ToString()))
            {
                return new ValidationResult(false, "未填写内容");
            }

            if(int.TryParse(value.ToString(),out var number))
            {
                if(number < 0)
                {
                    return new ValidationResult(false, "不能小于0");
                }
                return ValidationResult.ValidResult;
            }
            else
            {
                return new ValidationResult(false, "非法数字");
            }
        }
    }
}