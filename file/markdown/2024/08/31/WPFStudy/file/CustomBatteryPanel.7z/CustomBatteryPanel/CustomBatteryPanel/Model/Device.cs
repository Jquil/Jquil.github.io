﻿namespace CustomBatteryPanel.Model
{
    public class Device:ObservableObject
    {

        private string ip { get; set; }
        private int? id { get; set; }

        /// <summary>
        /// 设备IP
        /// </summary>
        public string IP
        {
            get
            {
                return ip;
            }
            set
            {
                ip = value;
                RaisePropertyChanged();
            }
        }


        /// <summary>
        /// 设备号
        /// </summary>
        public int? Id
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
                RaisePropertyChanged();
            }
        }
    }
}
