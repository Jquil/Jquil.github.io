﻿namespace CustomBatteryPanel.Model
{
    public enum ScrollDirection
    {
        H,
        V,
    }
}
