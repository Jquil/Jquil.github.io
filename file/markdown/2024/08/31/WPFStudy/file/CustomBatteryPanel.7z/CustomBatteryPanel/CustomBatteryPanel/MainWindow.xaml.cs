﻿using CustomBatteryPanel.Data;
using CustomBatteryPanel.Model;
using CustomBatteryPanel.View;
using CustomBatteryPanel.ViewModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace CustomBatteryPanel
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly MainViewModel _model;

        public MainWindow()
        {
            InitializeComponent();

            _model = new MainViewModel();

            this.DataContext = _model;

            RealDataBuffer.Instance.StartUpdateData();

            batteryPanel.Start();

        }

        private void AddDevice_Click(object sender, RoutedEventArgs e)
        {
            new AddDeviceWindow().ShowDialog();
        }

        private void TreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if(e.NewValue is Device device)
            {
                batteryPanel.DisplayBy(device.IP);
            }
            else if(e.NewValue is TreeViewItem viewItem && viewItem.Header?.ToString() == "设备列表")
            {
                batteryPanel.DisplayAll();
            }
        }

        private void DeleteDevice_Click(object sender, RoutedEventArgs e)
        {
            var item = treeView.SelectedItem;

            if(item is Device device)
            {
                var result = DeviceBuffer.Instance.RemoveDevice(device);
                if (!result.Success)
                {
                    MessageBox.Show(result.Message);
                }
            }
        }

        private void BatteryPanel_MouseUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var channels = batteryPanel.GetSelectedChannels();
            e.Handled = !channels.Any();
        }
    }
}
