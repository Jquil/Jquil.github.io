﻿using System.Windows;
using System.Windows.Media;

namespace CustomBatteryPanel.Model
{
    public class BatteryPanelConfig
    {
        /// <summary>
        /// 列数
        /// </summary>
        public int ColNumber { get; set; }

        /// <summary>
        /// 字体
        /// </summary>
        public FontFamily DrawFont { get; set; }

        /// <summary>
        /// 字体大小
        /// </summary>
        public double FontSize { get; set; }

        /// <summary>
        /// 字体颜色
        /// </summary>
        public System.Drawing.Color FontColor { get; set; }

        /// <summary>
        /// 通道大小
        /// </summary>
        public System.Windows.Size ChannelSize { get; set; }

        /// <summary>
        /// 通道内边距
        /// </summary>
        public Thickness ChannelPadding { get; set; }

        /// <summary>
        /// 通道外边距
        /// </summary>
        public Thickness ChannelMargin { get; set; }

        /// <summary>
        /// 自动大小
        /// </summary>
        public bool AutoSize { get; set; }

        /// <summary>
        /// 默认配置
        /// </summary>
        public static BatteryPanelConfig Default => new BatteryPanelConfig()
        {
            ColNumber = 5,
            DrawFont = new FontFamily("宋体"),
            FontSize = 10f,
            FontColor = System.Drawing.Color.Black,
            ChannelSize = new System.Windows.Size(200, 300),
            ChannelPadding = new Thickness(5),
            ChannelMargin = new Thickness(10),
            AutoSize = false,
        };
    }
}